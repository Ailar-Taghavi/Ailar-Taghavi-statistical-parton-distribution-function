#ifndef VEGAS_H
#define VEGAS_H

const short int _ndim_max = 10;

extern int ndim;                        // dimension of integration
extern int itmx;                        // count iteration
extern int init;                    // it should be so here
extern unsigned long calls;             // count calls sub-integration function
extern double regn[2*_ndim_max + 1];    // integration region
extern double tgral;                    // best estimate of the integral
extern double chi2a;                    // \xi^2 per degree of freedom
extern double sd;                       // standard deviation

extern void vegas(double regn[], int ndim, double (*fxn)(double [], double), int init, 
  unsigned long ncall, int itmx, int nprn, double *tgral, double *sd, double *chi2a);

#endif

