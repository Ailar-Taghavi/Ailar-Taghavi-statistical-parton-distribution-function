#ifndef DGLAP_H
#define DGLAP_H

extern double Pgg(double z); 
extern double Pqg(double z); 
extern double Pgq(double z); 
extern double Pqq(double z); 

extern double zPgg(double z); 

#endif


