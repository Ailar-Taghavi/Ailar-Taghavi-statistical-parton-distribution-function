// Unit name: utils.cpp
// Author: Artem Lipatov
// Last modified: 11.09.2007

#include <iostream>
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include "utils.h"

using namespace std;

bool isaQEDrun = true;

extern double spence(double x);

double GF(void)
{ 
  return 1.16639e-05;  // GeV^{-2}
}

double sin2W(void)
{ 
  return 0.23122;
}

double sinwma2(void)
{
  return 0.23116;
}



double aQED(void)
{ 
  return 1.0/137.0;
}

double aQEDr(double mu2)
{
  double alpha = 0.0;

  if (isaQEDrun == false) alpha = aQED();
    else alpha = 3.0/(3.0/(5.0*aQED()) - (41.0/10.0)*log(mu2/sqr(mE))/(4.0*PI))/5.0;

  return alpha;
}

double aQCD(double mu2)
{ 
  return 4.0*PI/((11.0 - 2.0*NF/3.0)*log(mu2/sqr(LQCD)));
}

double aQCDSS(double mu2)
{ 
  double b0 = 11.0 - 2.0*NF/3.0;
  double LQCD2 = sqr(LQCD);

  return (4.0*PI/b0)*(1.0/log(mu2/LQCD2) + LQCD2/(LQCD2 - mu2));
}

double L(double x, double y, double z)
{
  return x*x + y*y + z*z - 2.0*x*y - 2.0*x*z - 2.0*y*z;
}

double G(double x, double y, double z, double u, double v, double w)
{
  return x*z*w + x*u*v + y*z*v + y*u*w - x*y*(z + u + v + w - x - y) - 
    z*u*(x + y + v + w - z - u) - v*w*(x + y + z + u - v - w);
}

double WWA(double x, double Q2max)
{
  double _WWA = 0.0;
  double Q2min = sqr(5.11e-04*x/(1.0 - x));

  _WWA = (1.0 + sqr(1.0 - x))*log(Q2max/Q2min)/x + 2.0*sqr(5.11e-04)*x*(1.0/Q2max - 1.0/Q2min);
  if (_WWA < 0) goto Exit;
  
  _WWA = aQED()*_WWA/(2.0*PI); 
Exit:
  return _WWA;
}

double WWA(double x, double Q2min, double Q2max)
{
  double _WWA = 0.0;

  _WWA = (1.0 + sqr(1.0 - x))*log(Q2max/Q2min)/x + 2.0*sqr(5.11e-04)*x*(1.0/Q2max - 1.0/Q2min);
  if (_WWA < 0) goto Exit;
  
  _WWA = aQED()*_WWA/(2.0*PI); 
Exit:
  return _WWA;
}

double sqr(double x)
{
  return x*x;
}

double max(double x, double y)
{
  double _max = x;
  if (y > x) _max = y;

  return _max;
}

double min(double x, double y)
{
  double _min = x;
  if (y < x) _min = y;

  return _min;
}

void randomize(void)
{
  srand(time(NULL));
}

double random(double min, double max)
{
  return (max - min)*rand()/RAND_MAX + min;
}     

double random_sign(void)
{
  double _sign = 1.0;
  double _rand = random(0.0,1.0);

  if (_rand <= 0.5) _sign = - 1.0;

  return _sign;
}
