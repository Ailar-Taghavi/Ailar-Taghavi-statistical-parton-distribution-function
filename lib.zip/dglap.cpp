// Unit name: dglap.cpp
// Author: Artem Lipatov
// Last modified: 12.08.2009
// Description:
//   LO DGLAP splitting functions

#include <math.h>
#include "utils.h"
#include "dglap.h"

double Pgg(double z)
{
  return 2.0*NC*(z/(1.0 - z) - 1.0 + 1.0/z + z*(1.0 - z));
}

double Pgq(double z)
{
  return (4.0/3.0)*(1.0 + sqr(1.0 - z))/z;
}

double Pqg(double z)
{
  return (sqr(z) + sqr(1.0 - z));
}

double Pqq(double z)
{
  return (4.0/3.0)*(1 + sqr(z))/(1 - z);
}

double zPgg(double z)
{
  return z*Pgg(z);
}

