#ifndef NRUPDF_H
#define NRUPDF_H

#define SINGLE_SCALE 0
#define DOUBLE_SCALE 1

class nrupdf {
public:
  nrupdf(unsigned int = DOUBLE_SCALE);                                       
  ~nrupdf(void);                                       

  void load(const char *FileName);

  double get(double, double);
  double get(double, double, double);

  void set_arguments(double, double, double);
  void check_arguments(double, double, double);

  double x, xmin, xmax;
  double kt2, kt2min, kt2max;
  double mu2, mu2min, mu2max;

private:
  double *_x;
  double *_kt2;
  double *_mu2;
  double *_updf;

  long int count;
  unsigned int type;

  void load_single(const char *FileName);
  void load_double(const char *FileName);
};

#endif
