// Unit name: jet.cpp
// Author: Artem Lipatov
// Last modified: 12.06.2010

#include <math.h>
#include <stdlib.h>
#include "jet.h"
#include "utils.h"
#include "vector4.h"

void choose(vector4 p1, vector4 p2, vector4& pjet) 
{
  pjet = p1;

  if ( p1.transverse_momentum() < p2.transverse_momentum() ) pjet = p2;
}    

void choose(vector4 p1, vector4 p2, vector4 p3, vector4& pjet)
{
  vector4 k;

  choose(p1,p2,k);
  choose(k,p3,pjet);
}     

void choose(vector4 p1, vector4 p2, vector4 p3, vector4 p4, vector4& pjet)
{
  vector4 k1;
  vector4 k2;

  choose(p1,p2,k1);
  choose(p3,p4,k2);

  choose(k1,k2,pjet);
}     

void choose2(vector4 p1, vector4 p2, vector4& pjet1, vector4& pjet2) 
{
  pjet1 = p1;
  pjet2 = p2;

  if ( p1.transverse_momentum() < p2.transverse_momentum() ) 
  { 
    pjet1 = p2;
    pjet2 = p1;
  }
}    

void parton2jet(vector4 p1, vector4& p2, double ymin, double ymax)
{
  double y = random(ymin,ymax);
  double pt = p1.transverse_momentum();
  
  p2.set(pt*cosh(y), - p1.get(1), - p1.get(2), pt*sinh(y));
}

void parton2jet(vector4 p1, vector4& p2, double ymin, double ymax, double factor)
{
  double y = factor*random(ymin,ymax);
  double pt = p1.transverse_momentum();

  p2.set(pt*cosh(y), - p1.get(1), - p1.get(2), pt*sinh(y));
}

boolean separated_cone(vector4 p1, vector4 p2) 
{
  const double R2 = sqr(0.4);

  boolean _separated = TRUE;

  double dphi = phi(p1,p2);
  double eta1 = p1.pseudo_rapidity();
  double eta2 = p2.pseudo_rapidity();

  if ( sqr(eta2 - eta1) + sqr(dphi) <= R2 ) _separated = FALSE;

  return _separated;
}

boolean isolated_cone(vector4 p1, vector4 p2) // p1, p2 - photon and hadron 4-momenta
{
  boolean _isolated = TRUE;

  double Et1 = p1.transverse_energy();
  double Et2 = p2.transverse_energy();

  double eta1 = p1.pseudo_rapidity();
  double eta2 = p2.pseudo_rapidity();

  double dphi = phi(p1,p2);

  const double R2 = sqr(0.4);
  const double Emax = 5.0;

  if ( (sqr(eta2 - eta1) + sqr(dphi) <= R2) AND (Et2 >= Emax ) ) 
    _isolated = FALSE;

  return _isolated;
}


