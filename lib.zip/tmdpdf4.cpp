// Unit name: tmdpdf4.cpp
// Author: Artem Lipatov
// Last modified: 28.09.2014

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include "tmdpdf4.h"
#include "utils.h"

using namespace std;
using namespace uPDF;

extern bool first;
extern string filename;

extern double xmin, xmax;
extern double kt2min, kt2max;
extern double mu2min, mu2max;

tmdpdf4::tmdpdf4(void)
{
  _uv = 0.0;
  _dv = 0.0;
  _sea = 0.0;
  _gluon = 0.0;
}

void tmdpdf4::load(string inputfilename)
{
  double arr[13];
  double* xpq = &arr[6];

  first = true;
  filename = inputfilename;

  ccfmuPDF(2212,0.01,10.0,20.0,arr);
  
  _xmin = xmin;
  _xmax = xmax;
  
  _kt2min = kt2min;
  _kt2max = kt2max;
  
  _mu2min = mu2min;
  _mu2max = mu2max;

  cout << "Reading PDF grid from " << filename << endl;
}

void tmdpdf4::compute(double x, double kt2, double mu2)
{
  double arr[13];
  double* xpq = &arr[6];

  if (x < _xmin) { x = _xmin + ZERO; }
  if (x > _xmax) { x = _xmax - ZERO; }

  if (kt2 < _kt2min) { kt2 = _kt2min + ZERO; }
  if (kt2 > _kt2max) { kt2 = _kt2max - ZERO; }

  if (mu2 < _mu2min) { mu2 = _mu2min + ZERO; }
  if (mu2 > _mu2max) { mu2 = _mu2max - ZERO; }
  
  ccfmuPDF(2212,x,kt2,mu2,arr);

  _uv = xpq[2];
  _dv = xpq[1];
  _sea = xpq[3];
  _gluon = xpq[0];
}

double tmdpdf4::uv(void)
{
  return max(_uv,0.0);
}

double tmdpdf4::dv(void)
{
  return max(_dv,0.0);
}

double tmdpdf4::sea(void)
{
  return max(_sea,0.0);
}

double tmdpdf4::gluon(void)
{
  return max(_gluon,0.0);
}
