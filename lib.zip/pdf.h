#ifndef PDF_H
#define PDF_H

#include "mstwpdf.h"

const unsigned int GRV92 = 0;     // proton
const unsigned int GRV94 = 1;     // photon
const unsigned int MSTW2008 = 2;  // proton
const unsigned int CJKL2002 = 3;  // photon

const unsigned int KMR = 4;
const unsigned int KMRred = 5;
const unsigned int KMS = 6;
const unsigned int GBW = 7;  
const unsigned int CCFM = 8;  

class pdf {
public:
  pdf(unsigned int _set);
  pdf(unsigned int _set, const char *FileName);
  ~pdf(void);                                       

  int set;

  c_mstwpdf *mstwpdf; 

  double gluon(double x, double mu2);

  double u(double x, double mu2);
  double d(double x, double mu2);
  double s(double x, double mu2);
  double c(double x, double mu2);
  double b(double x, double mu2);
  double sb(double x, double mu2);
  double cb(double x, double mu2);
  double bb(double x, double mu2);
  double ubar(double x, double mu2);
  double dbar(double x, double mu2);
  double t(double x, double mu2);
  double tb(double x, double mu2);
  double uv(double x, double mu2);
  double dv(double x, double mu2);
};

#endif
