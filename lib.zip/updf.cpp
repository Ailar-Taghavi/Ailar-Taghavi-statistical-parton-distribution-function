// Unit name: updf.cpp
// Author: Artem Lipatov
// Last modified: 02.06.2009
// Description:
//   KMS and GBW unintegrated gluon densities in a proton

#include <math.h>
#include "updf.h"
#include "utils.h"
#include "nrupdf.h"

nrupdf nrkms(SINGLE_SCALE);

double kms(double x, double kt2)
{
  const double kt02 = sqr(1.0);

  double _updf = 0.0;

  if (kt2 > kt02) _updf = nrkms.get(x,kt2);
    else _updf = 1.57*pow(1.0 - x,2.5)/kt02;

  return _updf;
}

double gbw(double x, double kt2)
{
  const double alphas = 0.2;
  const double lambda = 0.277;
  const double x0 = 0.41e-04;
  const double Q0 = 1.0;

  double sigma0 = 29.12e+06/GeV2nb;
  double R0 = pow(x/x0,0.5*lambda)/Q0;
  double R02 = sqr(R0);

  return 3.0*sigma0*R02*kt2*exp( - R02*kt2)/(4.0*PI*PI*alphas);
}

double gbwmod(double x, double kt2)
{
  const double lambda = 0.22;
  const double x0 = 0.41e-04;
  const double Q0 = 1.0;
  const double alphas = 0.2;

  double sigma0 = 29.12e+06/GeV2nb;
  double R0 = pow(x/x0,0.5*lambda)/Q0;
  double R02 = sqr(R0);

  double bg = 12.0;
  double a = 0.7;
  double d = 0.2;

  double c0 = 3.0*sigma0/(4.0*PI*PI*alphas);
  double c3 = 0.3295;
  double c2 = 2.3;

  return c0*c3*pow(1.0 - x,bg)*(R02*kt2 + c2*pow(R0*sqrt(kt2),a))*exp( - R0*sqrt(kt2) - d*pow(R0*sqrt(kt2),3));
}

