#include <iostream>
#include <stdlib.h>
#include <math.h>
#include "../lib/pdf.h"
#include "../lib/kmr.h"
#include "../lib/nrupdf.h"
#include "../lib/updf.h"
#include "../lib/jet.h"
#include "../lib/utils.h"
#include "../lib/vegas.h"
#include "../lib/vector4.h"
#include "../lib/interface.h"

using namespace std;

extern model MODEL;
extern unsigned int PDF;
extern double S, scale_factor;
extern double Mmin, Mmax;
extern double qtmin, qtmax;

nrupdf uv(DOUBLE_SCALE);
nrupdf dv(DOUBLE_SCALE);

void title()
{
  cout << "**********************************************************************" << endl;
  cout << "* Program name: diphoton-hadro-qq.cpp                                *" << endl;
  cout << "* Author: Artem Lipatov                                              *" << endl;
  cout << "* Last modified: 08.11.2012                                          *" << endl;
  cout << "* Description:                                                       *" << endl;
  cout << "*   Main program for calculation of di-photon production             *" << endl;
  cout << "*   (via quark annihilation) in the hadron collisions using          *" << endl;
  cout << "*   the kt-factorization approach of QCD.                            *" << endl;
  cout << "**********************************************************************" << endl;

  display(MODEL,PDF);

  cout << "       Ecm = " << sqrt(S) << " GeV" << endl;
  cout << "       scale factor = " << scale_factor << endl;
  cout << "       number of flavours = " << NF << endl;
  cout << "       QCD parameter = " << LQCD*1000.0 << " MeV" << endl;
}

pdf grv94(GRV94);
pdf mstw(MSTW2008,"mstw2008lo.00.dat");
pdf *KMR_INPUT;

extern void arrange(void);

extern void save1960(void);
extern void save7000(void);
extern void put1960(vector4 k1, vector4 k2, vector4 k3, vector4 k4, double dsigma);
extern void put7000(vector4 k1, vector4 k2, vector4 k3, vector4 k4, double dsigma);

extern double qq2GG(vector4 k1, vector4 l1, vector4 k2, vector4 l2, vector4 k3, vector4 k4, double eQ);

double calc_qq2GG(double x[], double wgt)
{
  double muR2, muF2, J, M, F, pdfs;
  double qt, kt12, kt22, kt32, kt42; 
  double y3, y4, phi1, phi2, phi3; 
  double s, t, u;
  double x1, x2;
  double _u, _d, _s, _c, _sea1, _sea2;
  vector4 k1, k2, k3, k4, l1, l2, q;

  double dsigma = 0.0;

  kt32 = sqr(exp(x[1]));
  y3 = x[2];
  y4 = x[3];
  phi1 = x[4];
  phi2 = x[5];

  kt12 = ZERO;
  kt22 = ZERO;
  J = 2.0*kt32;  

  if ( MODEL == kT )
  {
    kt12 = sqr(exp(x[6]));
    kt22 = sqr(exp(x[7]));

    J = 4.0*kt12*kt22*J;
  }  

  phi3 = random(0.0,2.0*PI);

  k3.set(sqrt(kt32)*cosh(y3),sqrt(kt32)*cos(phi3),sqrt(kt32)*sin(phi3),sqrt(kt32)*sinh(y3));
  
  k1.set(1,sqrt(kt12)*cos(phi1));
  k1.set(2,sqrt(kt12)*sin(phi1));

  k2.set(1,sqrt(kt22)*cos(phi2));
  k2.set(2,sqrt(kt22)*sin(phi2));

  k4.set(1,k1.get(1) + k2.get(1) - k3.get(1));
  k4.set(2,k1.get(2) + k2.get(2) - k3.get(2));

  kt42 = k4.transverse_momentum2();

  k4.set(0,sqrt(kt42)*cosh(y4));
  k4.set(3,sqrt(kt42)*sinh(y4));

  x1 = ( sqrt(kt32)*exp(y3) + sqrt(kt42)*exp(y4) )/sqrt(S); if (x1 >= 1.0) goto Exit;
  x2 = ( sqrt(kt32)*exp( - y3) + sqrt(kt42)*exp( - y4) )/sqrt(S); if (x2 >= 1.0) goto Exit;

  k1.set(0,x1*sqrt(S)/2.0);
  k1.set(3,x1*sqrt(S)/2.0);

  k2.set(0,x2*sqrt(S)/2.0);
  k2.set(3, - x2*sqrt(S)/2.0);

  l1.set(x1*sqrt(S)/2.0,0.0,0.0,x1*sqrt(S)/2.0);
  l2.set(x2*sqrt(S)/2.0,0.0,0.0, - x2*sqrt(S)/2.0);

  q.set(0,k3.get(0) + k4.get(0));
  q.set(1,k3.get(1) + k4.get(1));
  q.set(2,k3.get(2) + k4.get(2));
  q.set(3,k3.get(3) + k4.get(3));

  qt = q.transverse_momentum();

  t = dot(k2,k2) + dot(k4,k4) - 2.0*dot(k2,k4);
  u = dot(k2,k2) + dot(k3,k3) - 2.0*dot(k2,k3);
  s = dot(k1,k1) + dot(k2,k2) + 2.0*dot(k1,k2);

  if ( G(s,t,0.0,dot(k1,k1),dot(k2,k2),0.0) > 0.0 ) goto Exit;
  if ( L(s,dot(k1,k1),dot(k2,k2)) < 0.0 ) goto Exit;
  if ( L(s,0.0,0.0) < 0.0 ) goto Exit;

  if (separated_cone(k3,k4) == FALSE) goto Exit;

  M = inv_mass(k3,k4);

  if (M < Mmin) goto Exit;
  if (M > Mmax) goto Exit;

  if (qt < qtmin) goto Exit;
  if (qt > qtmax) goto Exit;

  muR2 = max(1.0,scale_factor*sqr(M));
  muF2 = max(1.0,scale_factor*sqr(M));
//  muF2 = max(1.0,kt12 + kt22 + 2.0*sqrt(kt12*kt22)*cos(phi(k1,k2)));

  if ( (MODEL == LO) AND (PDF == MSTW2008) ) 
  {
    _u = mstw.u(x1,muF2)*mstw.u(x2,muF2) + mstw.ubar(x1,muF2)*mstw.ubar(x2,muF2); 
    _d = mstw.d(x1,muF2)*mstw.d(x2,muF2) + mstw.dbar(x1,muF2)*mstw.dbar(x2,muF2); 

    _s = 2.0*mstw.s(x1,muF2)*mstw.s(x2,muF2); 
    _c = 2.0*mstw.c(x1,muF2)*mstw.c(x2,muF2); 
  }

  if ( (MODEL == kT) AND (PDF == KMR) ) 
  { 
    KMR_INPUT = &mstw; 

    _sea1 = kmr_sea(x1,kt12,muF2);
    _sea2 = kmr_sea(x2,kt22,muF2);

//    _u = kmr_u(x1,kt12,muF2)*kmr_u(x2,kt22,muF2) + _sea1*_sea2;
//    _d = kmr_d(x1,kt12,muF2)*kmr_d(x2,kt22,muF2) + _sea1*_sea2;
    
// valence only    
    _u = kmr_uv(x1,kt12,muF2)*kmr_uv(x2,kt22,muF2);
    _d = kmr_dv(x1,kt12,muF2)*kmr_dv(x2,kt22,muF2);

    _s = 0.0;
    _c = 0.0;
  }

  if ( (MODEL == kT) AND (PDF == CCFM) ) 
  { 
    _sea1 = 0.0;
    _sea2 = 0.0;    

    _u = uv.get(x1,kt12,sqrt(muF2))*uv.get(x2,kt22,sqrt(muF2));
    _d = dv.get(x1,kt12,sqrt(muF2))*dv.get(x2,kt22,sqrt(muF2));

    _s = 0.0;
    _c = 0.0;
  }

  pdfs = _u + _d/16.0 + _s/16.0 + _c;

  dsigma = J*pdfs*qq2GG(k1,l1,k2,l2,k3,k4,eU)/(16.0*PI*sqr(x1*x2*S)*sqr(2.0*PI));

  if ( dsigma <= 0.0) goto Exit;

  dsigma = GeV2pb*dsigma;     

  F = 1.0 + M*M*M;

  if (init > 0) 
  {
    if ( S == sqr(1960.0) ) put1960(k1,k2,k3,k4,F*wgt*dsigma/itmx);
    if ( S == sqr(7000.0) ) put7000(k1,k2,k3,k4,F*wgt*dsigma/itmx);
  }

Exit:
  return F*dsigma;
}

main(void)
{
  title();
  arrange();
  randomize();

  if (PDF == CCFM) 
  { 
    uv.load("ccfm-u-valence.dat");
    dv.load("ccfm-d-valence.dat");
  }

  if (MODEL == LO) 
  {
    ndim = 5;

    regn[1] = log(1.0e+01);    regn[6] = log(1.0e+03);
    regn[2] = - 3.0;           regn[7] = 3.0;
    regn[3] = - 3.0;           regn[8] = 3.0;
    regn[4] = 0.0;             regn[9] = 2.0*PI;
    regn[5] = 0.0;             regn[10] = 2.0*PI;
  }
    else
  {
    ndim = 7;

    regn[1] = log(1.0e+01);    regn[8] = log(1.0e+03);
    regn[2] = - 3.0;           regn[9] = 3.0;
    regn[3] = - 3.0;           regn[10] = 3.0;
    regn[4] = 0.0;             regn[11] = 2.0*PI;
    regn[5] = 0.0;             regn[12] = 2.0*PI;
    regn[6] = log(0.001);      regn[13] = log(1.0e+03);
    regn[7] = log(0.001);      regn[14] = log(1.0e+03);
  }

  init = 0;
  itmx = 20;
  calls = 10000;

  vegas(regn,ndim,calc_qq2GG,init,calls,itmx,0,&tgral,&sd,&chi2a);

  init = 1;
  itmx = 50;
  calls = 800000;

  vegas(regn,ndim,calc_qq2GG,init,calls,itmx,0,&tgral,&sd,&chi2a);
  cout << "\nq + q contribution: " << tgral << " (sd = " << sd << ", chi2a = " << chi2a << ")\n";

  if ( S == sqr(1960.0) ) save1960();
  if ( S == sqr(7000.0) ) save7000();
}


