#ifndef TMDPDF4_H
#define TMDPDF4_H

#include "UPDF.h"

class tmdpdf4 {
public:
  tmdpdf4(void);                                       

  void load(string inputfilename);
  void compute(double x, double kt2, double mu2);

  double uv(void);
  double dv(void);
  double sea(void);
  double gluon(void);

private:
  double _uv;
  double _dv;
  double _sea;
  double _gluon;

  double _xmin, _xmax;
  double _kt2min, _kt2max;
  double _mu2min, _mu2max;
};

#endif
