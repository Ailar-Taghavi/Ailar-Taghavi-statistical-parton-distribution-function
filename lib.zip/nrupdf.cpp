// Unit name: nrupdf.cpp
// Author: Artem Lipatov
// Last modified: 26.12.2008

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <math.h>
#include "utils.h"
#include "nrupdf.h"

using namespace std;

nrupdf::nrupdf(unsigned int _type)
{
  if ( (_type != SINGLE_SCALE) AND (_type != DOUBLE_SCALE) ) 
  {
    cout << "  Error (nr_updf): incorrect type of updf(s). Program will be terminated..." << endl; 
    exit(0);
  }

  count = 0;
  type = _type;
}

nrupdf::~nrupdf()
{
  delete _x;
  delete _kt2;
  delete _mu2;
  delete _updf;
}

void nrupdf::set_arguments(double _x, double _kt2, double _mu2)
{
  x = _x;
  kt2 = _kt2;
  mu2 = _mu2;
}

void nrupdf::check_arguments(double _x, double _kt2, double _mu2)
{
  if (_x < xmin) { _x = xmin + ZERO; }
  if (_x > xmax) { _x = xmax - ZERO; }

  if (_kt2 < kt2min) { _kt2 = kt2min + ZERO; }
  if (_kt2 > kt2max) { _kt2 = kt2max - ZERO; }

  if (_mu2 < mu2min) { _mu2 = mu2min + ZERO; }
  if (_mu2 > mu2max) { _mu2 = mu2max - ZERO; }

  set_arguments(_x,_kt2,_mu2);
}

void nrupdf::load(const char *FileName)
{
  if (type == SINGLE_SCALE) load_single(FileName);
  if (type == DOUBLE_SCALE) load_double(FileName);
}

void nrupdf::load_single(const char *FileName)
{
  long int I;
  FILE *File;

  float __x, __kt2, __updf;

  xmin = 1.0; 
  xmax = 0.0;

  kt2min = 1.0e+10; 
  kt2max = 0.0;

  if ((File = fopen(FileName,"r")) == NULL)
  {
    cout << "  Error (nr_updf): file '" << FileName << "' is absent. Program will be terminated..." << endl;
    exit(0);
  }

  count = 0;
  while (fscanf(File,"%f %f %f",&__x,&__kt2,&__updf) != EOF)
    count = count + 1;

  _x = new double[count];
  _kt2 = new double[count];
  _mu2 = new double[count];
  _updf = new double[count];

  I = 0;
  rewind(File);
  while (fscanf(File,"%f %f %f",&__x,&__kt2,&__updf) != EOF)
  {
    _x[I] = __x;
    _kt2[I] = __kt2;
    _updf[I] = __updf/_kt2[I];

    if (_x[I] < xmin) xmin = _x[I];
    if (_x[I] > xmax) xmax = _x[I];

    if (_kt2[I] < kt2min) kt2min = _kt2[I];
    if (_kt2[I] > kt2max) kt2max = _kt2[I];

    I = I + 1;
  }

  fclose(File);

  cout << endl;
  cout << "File '" << FileName << "' has been loaded successfully..." << endl;
}

void nrupdf::load_double(const char *FileName)
{
  long int I;
  FILE *File;

  float __x, __kt2, __mu2, __updf;

  xmin = 1.0;
  xmax = 0.0;

  kt2min = 1.0e+10;
  kt2max = 0.0;

  mu2min = 1.0e+10;
  mu2max = 0.0;

  if ((File = fopen(FileName,"r")) == NULL)
  {
    cout << "  Error (nr_updf): file '" << FileName << "' is absent. Program will be terminated..." << endl;
    exit(0);
  }

  count = 0;
  while (fscanf(File,"%f %f %f %f",&__x,&__kt2,&__mu2,&__updf) != EOF)
    count = count + 1;

  _x = new double[count];
  _kt2 = new double[count];
  _mu2 = new double[count];
  _updf = new double[count];

  I = 0;
  rewind(File);
  while (fscanf(File,"%f %f %f %f",&__x,&__kt2,&__mu2,&__updf) != EOF)
  {
    _x[I] = exp(__x);
    _kt2[I] = exp(__kt2);
    _mu2[I] = exp(__mu2);
    _updf[I] = __updf/(_kt2[I]);

    if (_x[I] < xmin) xmin = _x[I];
    if (_x[I] > xmax) xmax = _x[I];

    if (_kt2[I] < kt2min) kt2min = _kt2[I];
    if (_kt2[I] > kt2max) kt2max = _kt2[I];

    if (_mu2[I] < mu2min) mu2min = _mu2[I];
    if (_mu2[I] > mu2max) mu2max = _mu2[I];

    I = I + 1;
  }

  fclose(File);

  cout << endl;
  cout << "File '" << FileName << "' has been loaded successfully..." << endl;
}

double nrupdf::get(double __x, double __kt2)
{
  long int I;
  double a1, a2, a3, a4;
  double f11, f12, f21, f22;

  double __updf = 0.0;

  float x1 = xmin;
  float x2 = xmax;
  float y1 = kt2min;
  float y2 = kt2max;

  if (type == DOUBLE_SCALE) goto Exit;  
  if (count == 0) { cout << "  Error (nr_updf): data file is not loaded. Program will be terminated..." << endl; exit(0); }

  check_arguments(__x,__kt2,10.0);

  for (I = 0; I < count; I++)
  {
    if  ( (x == _x[I]) AND (kt2 == _kt2[I]) ) { __updf = _updf[I]; goto Exit; }

    if ( (_kt2[I] > y1) AND (kt2 >= _kt2[I]) ) y1 = _kt2[I];
    if ( (_kt2[I] < y2) AND (kt2 < _kt2[I]) ) y2 = _kt2[I];
   
    if ( (_x[I] > x1) AND (x >= _x[I]) ) x1 = _x[I];
    if ( (_x[I] < x2) AND (x < _x[I]) ) x2 = _x[I];

    if ( (x1 == _x[I]) AND (y1 == _kt2[I]) ) f11 = _updf[I];
    if ( (x1 == _x[I]) AND (y2 == _kt2[I]) ) f12 = _updf[I];
    if ( (x2 == _x[I]) AND (y1 == _kt2[I]) ) f21 = _updf[I];
    if ( (x2 == _x[I]) AND (y2 == _kt2[I]) ) f22 = _updf[I];
  }

  if (y1 == y2) 
  {
    __updf = (f11 - f21)*x/(x1 - x2) + (f21*x1 - f11*x2)/(x1 - x2);
    goto Exit;
  }

  a1 = (f11 + f22 - f12 - f21)/((x1 - x2)*(y1 - y2));
  a2 = ((f12 - f22)*y1 - (f11 - f21)*y2)/((x1 - x2)*(y1 - y2));

  a3 = ((f21 - f22)*x1 - (f11 - f12)*x2)/((x1 - x2)*(y1 - y2));
  a4 = ((f22*x1 - f12*x2)*y1 - (f21*x1 - f11*x2)*y2)/((x1 - x2)*(y1 - y2));

  __updf = a1*x*kt2 + a2*x + a3*kt2 + a4;

Exit:
  if (__updf < 0.0) __updf = 0.0;
  return __updf;
}

double nrupdf::get(double __x, double __kt2, double __mu2)
{
  long int I;
  double __updf = 0.0;

  double x1 = xmin;
  double x2 = xmax;
  double y1 = kt2min;
  double y2 = kt2max;
  double z1 = mu2min;
  double z2 = mu2max;

  double f111, f112, f121, f122, f211, f212, f221, f222;

  if (type == SINGLE_SCALE) goto Exit;  
  if (count == 0) { cout << "  Error (nr_updf): data file is not loaded. Program will be terminated..." << endl; exit(0); }

  check_arguments(__x,__kt2,__mu2);

  for (I = 0; I < count; I++)
  {
    if  ( (x == _x[I]) AND (kt2 == _kt2[I]) AND (mu2 == _mu2[I]) ) { __updf = _updf[I]; goto Exit; }

    if ( (_kt2[I] > y1) AND (kt2 >= _kt2[I]) ) y1 = _kt2[I];
    if ( (_kt2[I] < y2) AND (kt2 < _kt2[I]) ) y2 = _kt2[I];
   
    if ( (_x[I] > x1) AND (x >= _x[I]) ) x1 = _x[I];
    if ( (_x[I] < x2) AND (x < _x[I]) ) x2 = _x[I];

    if ( (_mu2[I] > z1) AND (mu2 >= _mu2[I]) ) z1 = _mu2[I];
    if ( (_mu2[I] < z2) AND (mu2 < _mu2[I]) ) z2 = _mu2[I];

    if ( (x1 == _x[I]) AND (y1 == _kt2[I]) AND (z1 == _mu2[I]) ) f111 = _updf[I];
    if ( (x1 == _x[I]) AND (y1 == _kt2[I]) AND (z2 == _mu2[I]) ) f112 = _updf[I];
    if ( (x1 == _x[I]) AND (y2 == _kt2[I]) AND (z1 == _mu2[I]) ) f121 = _updf[I];
    if ( (x1 == _x[I]) AND (y2 == _kt2[I]) AND (z2 == _mu2[I]) ) f122 = _updf[I];
    if ( (x2 == _x[I]) AND (y1 == _kt2[I]) AND (z1 == _mu2[I]) ) f211 = _updf[I];
    if ( (x2 == _x[I]) AND (y1 == _kt2[I]) AND (z2 == _mu2[I]) ) f212 = _updf[I];
    if ( (x2 == _x[I]) AND (y2 == _kt2[I]) AND (z1 == _mu2[I]) ) f221 = _updf[I];
    if ( (x2 == _x[I]) AND (y2 == _kt2[I]) AND (z2 == _mu2[I]) ) f222 = _updf[I];
  }

  __updf = ( f111*(x2 - x)*(y2 - kt2)*(z2 - mu2) + f112*(x2 - x)*(y2 - kt2)*(mu2 - z1) + 
    f121*(x2 - x)*(kt2 - y1)*(z2 - mu2) + f122*(x2 - x)*(kt2 - y1)*(mu2 - z1) + 
    f211*(x - x1)*(y2 - kt2)*(z2 - mu2) + f212*(x - x1)*(y2 - kt2)*(mu2 - z1) + 
    f221*(x - x1)*(kt2 - y1)*(z2 - mu2) + f222*(x - x1)*(kt2 - y1)*(mu2 - z1) )/( (x2 - x1)*(y2 - 
      y1)*(z2 - z1) ); 

Exit:
  if (__updf < 0.0) __updf = 0.0;
  return __updf;
}

