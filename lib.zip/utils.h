#ifndef UTILS_H
#define UTILS_H

#define AND &&
#define OR ||

#define EQUAL ==
#define NOT_EQUAL !=

enum boolean {TRUE, FALSE};

const short int NC = 3;                                          // colors
const short int NF = 4;                                          // quark flavours
const double PI = 3.14159;
const double LQCD = 0.200;                                       // QCD parameter, GeV
const double ZERO = 1.0e-10;

const double GeV2nb = 4.0e+05;
const double GeV2pb = 4.0e+08;
const double GeV2fb = 4.0e+12;
const double nb2pb = 1.0e+03;
const double pb2nb = 1.0e-03;

const double rad2grad = 180.0/PI;
const double grad2rad = PI/180.0;

const double eU = 2.0/3.0;                                       // u-quark charge
const double eD = - 1.0/3.0;                                     // d-quark charge
const double eS = - 1.0/3.0;                                     // s-quark charge
const double eC = 2.0/3.0;                                       // c-quark charge
const double eB = - 1.0/3.0;                                     // b-quark charge
const double eT = 2.0/3.0;                                       // t-quark charge

const double mU = 0.0045;                                        // u-quark mass, GeV
const double mD = 0.0085;                                        // d-quark mass, GeV
const double mS = 0.155;                                         // s-quark mass, GeV
const double mC = 1.5;                                           // c-quark mass, GeV
const double mB = 4.75;                                          // b-quark mass, GeV
const double mT = 172.0;                                         // t-quark mass, GeV

const double mE = 0.000511;                                      // electron mass, GeV
const double mMu = 0.105;                                        // muon mass, GeV
const double mW = 80.403;                                        // W mass, GeV
const double mZ = 91.1876;                                       // Z mass, GeV

const double mD0 = 1.8645;                                       // D^0 mass, GeV
const double mDpm = 1.8693;                                      // D^{+/-} mass, GeV
const double mDstar = 2.010;                                     // D^* mass, GeV
const double mDs = 1.968;                                        // D_s mass, GeV
const double mK = 0.493;                                         // K mass, GeV
const double mPi = 0.13957;                                      // Pi^{+/-} mass, GeV
const double mB0 = 5.279;                                        // B^{0} mass, GeV
const double mBpm = 5.279;                                       // B^{+/-} mass, GeV

const double mChic0 = 3.415;                                     // chi_{c0} mass, GeV
const double mChic1 = 3.511;                                     // chi_{c1} mass, GeV
const double mChic2 = 3.556;                                     // chi_{c2} mass, GeV
const double mPsi2S = 3.686;                                     // Psi(2S) mass, GeV
const double mJPsi = 3.097;                                      // J/Psi mass, GeV

const double mChib01P = 9.85944;                                 // chi_{b0}(1P) mass, GeV
const double mChib02P = 10.2325;                                 // chi_{b0}(2P) mass, GeV
const double mChib11P = 9.89278;                                 // chi_{b1}(1P) mass, GeV
const double mChib12P = 10.25546;                                // chi_{b1}(2P) mass, GeV
const double mChib13P = 10.530;                                  // chi_{b1}(3P) mass, GeV
const double mChib21P = 9.91221;                                 // chi_{b2}(1P) mass, GeV
const double mChib22P = 10.26865;                                // chi_{b2}(2P) mass, GeV
const double mChib23P = 10.530;                                  // chi_{b2}(3P) mass, GeV
const double mUpsilon1S = 9.460;                                 // Upsilon(1S) mass, GeV
const double mUpsilon2S = 10.02326;                              // Upsilon(2S) mass, GeV
const double mUpsilon3S = 10.3552;                               // Upsilon(3S) mass, GeV

const double I3uct = 1.0/2.0;                                    // weak isospin (u, c, t)
const double I3dsb = - 1.0/2.0;                                  // weak isospin (d, s, b)
 
const double GZ = 2.4952;                                        // full width for Z, GeV

// branching ratios

const double BRc2D0 = 0.559;
const double BRc2Ds = 0.084;
const double BRc2Dpm = 0.239;
const double BRc2Dstar = 0.235;
const double BRc2e = 0.096;
const double BRc2mu = 0.0969;

const double BRb2B0 = 0.398;
const double BRb2Bpm = 0.398;
const double BRb2e = 0.221;
const double BRb2mu = 0.1071;
const double BRb2c2mu = 0.0802;

const double BRW2lnu = 0.1075;
const double BRZ2ll = 0.03366;

const double BRChic12JPsi = 0.356;
const double BRChic22JPsi = 0.202;
const double BRPsi2JPsi = 0.561;
const double BRJPsi2mumu = 0.0593;

const double BRChib11P2Upsilon1S = 0.35;
const double BRChib12P2Upsilon1S = 0.085;
const double BRChib12P2Upsilon2S = 0.21;
const double BRChib13P2Upsilon3S = 0.09;
const double BRChib21P2Upsilon1S = 0.22;
const double BRChib22P2Upsilon1S = 0.071;
const double BRChib22P2Upsilon2S = 0.162;
const double BRChib23P2Upsilon3S = 0.06;

const double BRUpsilon2S2Upsilon1SPiPi = 0.181;
const double BRUpsilon2S2Upsilon1SPi0Pi0 = 0.086;
const double BRUpsilon3S2Upsilon2S = 0.106;
const double BRUpsilon3S2Upsilon1SPiPi = 0.044;
const double BRUpsilon3S2Upsilon1SPi0Pi0 = 0.022;

const double BRUpsilon1S2mumu = 0.0248;
const double BRUpsilon2S2mumu = 0.0193;
const double BRUpsilon3S2mumu = 0.0218;

// CKB matrix elements

const double Vud = 0.97377;
const double Vus = 0.2257;
const double Vcd = 0.230;
const double Vcs = 0.957;
const double Vcb = 0.0416;
const double Vub = 0.00431;
const double Vtd = 0.00814;
const double Vts = 0.04161;
const double Vtb = 0.99910;
        
extern double GF(void);                                          // Fermi constant, GeV^{-2}
extern double sin2W(void);                                       // sin of Weinberg ang  
extern double sinwma2(void);                     
extern double aQED(void);                                        // QED constant
extern double aQEDr(double);
extern double aQCD(double);                                      // QCD running constant
extern double aQCDSS(double);                                    // Shirkov-Solovtsov QCD running constant

extern double WWA(double, double);                               // Weizacker-Williams approximation
extern double WWA(double, double, double);                       // Weizacker-Williams approximation

extern double L(double, double, double);                         // kinematical function L
extern double G(double, double, double, double, double, double); // kinematical function G

extern double sqr(double);
extern double max(double, double);
extern double min(double, double);

extern void randomize(void);

extern double random_sign(void);
extern double random(double min, double max);


#endif

