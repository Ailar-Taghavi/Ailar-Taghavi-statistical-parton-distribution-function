// Unit name: cjkl.cpp
// Author: Artem Lipatov
// Last modified: 25.09.2009
// Description:
//   CJKL (collinear) LO parton densities in a photon
//   F. Cornet, P. Jankowski, M. Krawczyk, and A. Lorca, Phys. Rev. D 68, 014010 (2003)

#include <iostream>
#include <math.h>
#include "cjkl.h"
#include "utils.h"

using namespace std;

double up_pl(double x, double mu2);
double down_pl(double x, double mu2);
double strange_pl(double x, double mu2);
double charm_pl(double x, double mu2);
double beauty_pl(double x, double mu2);
double gluon_pl(double x, double mu2);

double sea_hdl(double x, double mu2);
double valence_hdl(double x, double mu2);
double charm_hdl(double x, double mu2);
double beauty_hdl(double x, double mu2);
double gluon_hdl(double x, double mu2);

double cjkl_gluon(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
    else return gluon_pl(x,mu2) + gluon_hdl(x,mu2);
}

double cjkl_up(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
    else return up_pl(x,mu2) + 0.5*valence_hdl(x,mu2) + sea_hdl(x,mu2);
}

double cjkl_down(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
  else return down_pl(x,mu2) + 0.5*valence_hdl(x,mu2) + sea_hdl(x,mu2);
}

double cjkl_strange(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
    else return strange_pl(x,mu2) + sea_hdl(x,mu2);
}

double cjkl_charm(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
    else return charm_pl(x,mu2) + charm_hdl(x,mu2);
}

double cjkl_beauty(double x, double mu2)
{
  if ( (x <= 0.0) OR (x > 1.0) ) return 0.0;
    else return beauty_pl(x,mu2) + beauty_hdl(x,mu2);
}

double gluon_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _gluon = 0.0;

  double a = 0.2368 - 0.1185*s;
  double b = - 0.1999 + 0.02812*s;
  double alpha = - 0.4387;
  double alpha_prime = 2.717;
  double beta = 0.3675;

  double A = 0.08689 - 0.3499*s;
  double B = 0.01056 + 0.04953*s; 
  double C = - 0.09900 + 0.34830*s;
  double D = 1.065 + 0.1434*s;
  double E = 3.672 + 2.507*s; 
  double E_prime = 2.194 + 1.936*s; 
  double dlg = log(1.0/x);

  _gluon = pow(s,alpha)*pow(x,a)*(A + B*sqrt(x) + C*pow(x,b));
  _gluon = _gluon + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _gluon = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_gluon*pow(1.0 - x,D);

  return _gluon*aQED();
}

double gluon_hdl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _gluon = 0.0;

  double a = - 0.349479 + 0.470584*s;
  double alpha = 0.599449;
  double beta = 1.12849;

  double A = - 0.19898 + 0.57414*s;
  double B = 1.99417 - 1.83060*s; 
  double C = - 1.98480 + 1.41359*s;
  double D = 0.212938 + 2.74500*s;
  double E = 1.22871 + 2.44470*s; 
  double E_prime = 4.92304 + 0.185258*s; 
  double dlg = log(1.0/x);

  _gluon = pow(x,a)*(A + B*sqrt(x) + C*x);
  _gluon = _gluon + pow(s,alpha)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _gluon = _gluon*pow(1.0 - x,D);

  return _gluon*aQED();
}

double up_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _up = 0.0;

  double a = 0.87940 - 0.110241*s;
  double b = 2.6878 - 0.040252*s;
  double alpha = - 1.0711;
  double alpha_prime = 3.1320;
  double beta = 0.69243;

  double A = - 0.058266 + 0.20506*s;
  double B = 0.0097377 - 0.10617*s; 
  double C = - 0.0068345 + 0.15211*s;
  double D = 0.22297 + 0.013567*s;
  double E = 6.4289 + 2.2802*s; 
  double E_prime = 1.7302 + 0.76997*s; 
  double dlg = log(1.0/x);

  _up = pow(s,alpha)*pow(x,a)*(A + B*sqrt(x) + C*pow(x,b));
  _up = _up + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _up = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_up*pow(1.0 - x,D);

  return _up*aQED();
}

double down_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _down = 0.0;

  double a = 11.777 + 0.034760*s;
  double b = - 11.124 - 0.20135*s;
  double alpha = - 1.1357;
  double alpha_prime = 3.1187;
  double beta = 0.66290;

  double A = 0.098814 - 0.067300*s;
  double B = - 0.092892 + 0.049949*s; 
  double C = - 0.006140 + 0.020427*s;
  double D = - 0.31385 - 0.0037558*s;
  double E = 6.4671 + 2.2834*s; 
  double E_prime = 1.6996 + 0.84262*s; 
  double dlg = log(1.0/x);

  _down = pow(s,alpha)*pow(x,a)*(A + B*sqrt(x) + C*pow(x,b));
  _down = _down + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _down = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_down*pow(1.0 - x,D);

  return _down*aQED();
}

double strange_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _strange = 0.0;

  double a = 11.777 + 0.034760*s;
  double b = - 11.124 - 0.20135*s;
  double alpha = - 1.1357;
  double alpha_prime = 3.1187;
  double beta = 0.66290;

  double A = 0.098814 - 0.067300*s;
  double B = - 0.092892 + 0.049949*s; 
  double C = - 0.006140 + 0.020427*s;
  double D = - 0.31385 - 0.0037558*s;
  double E = 6.4671 + 2.2834*s; 
  double E_prime = 1.6996 + 0.84262*s; 
  double dlg = log(1.0/x);

  _strange = pow(s,alpha)*pow(x,a)*(A + B*sqrt(x) + C*pow(x,b));
  _strange = _strange + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _strange = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_strange*pow(1.0 - x,D);

  return _strange*aQED();
}

double charm_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _charm = 0.0;

  double a, b, alpha, alpha_prime, beta;
  double A, B, C, D, E, E_prime;

  double dlg = log(1.0/x);
  double y = x + 1.0 - mu2/(mu2 + 6.76);

  if (y > 1.0) goto Exit;

  if (mu2 <= 10.0)
  {
    a = - 7.6307 + 5.6807*s;
    b = 394.58 - 541.82*s + 200.82*sqr(s);
    alpha = 2.9808;
    alpha_prime = 28.682;
    beta = 2.4863;

    A = - 0.18826 + 0.13565*s;
    B = 0.18508 - 0.11764*s; 
    C = - 0.0014153 - 0.011510*s;
    D = - 0.48961 + 0.18810*s;
    E = 0.20911 - 2.8544*s + 14.256*sqr(s); 
    E_prime = 2.7644 + 0.93717*s; 
  }

  if (mu2 > 10.0)
  {
    a = - 0.30307 + 0.29430*s;
    b = 7.2383 - 1.5995*s;
    alpha = - 1.8095;
    alpha_prime = 7.9399;
    beta = 0.041563;

    A = - 0.54831 + 0.33412*s;
    B = 0.19484 + 0.041562*s; 
    C = - 0.39046 + 0.37194*s;
    D = 0.12717 + 0.059280*s;
    E = 8.7191 + 3.0194*s; 
    E_prime = 4.2616 + 0.73993*s; 
  }

  _charm = pow(s,alpha)*pow(y,a)*(A + B*sqrt(y) + C*pow(y,b));
  _charm = _charm + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _charm = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_charm*pow(1.0 - y,D);

Exit:
  return _charm*aQED();
}

double beauty_pl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _beauty = 0.0;

  double a, b, alpha, alpha_prime, beta;
  double A, B, C, D, E, E_prime;

  double dlg = log(1.0/x);
  double y = x + 1.0 - mu2/(mu2 + 73.96);

  if (y > 1.0) goto Exit;

  if (mu2 <= 100.0)
  {
    a = 3.8140 - 1.0514*s;
    b = 2.2292 + 20.194*s;
    alpha = 2.2849;
    alpha_prime = 6.0408;
    beta = - 0.11577;

    A = - 0.26971 + 0.17942*s;
    B = 0.27033 - 0.18358*s + 0.0061059*sqr(s); 
    C = 0.0022862 - 0.0016837*s;
    D = 0.30807 - 0.10490*s;
    E = 14.812 - 1.2977*s; 
    E_prime = 1.7148 + 2.3532*s + 0.053734*sqrt(s); 
  }

  if (mu2 > 100.0)
  {
    a = - 0.084651 - 0.083206*s;
    b = 9.6036 - 3.4864*s;
    alpha = - 5.0607;
    alpha_prime = 16.590;
    beta = 0.87190;

    A = - 0.72790 + 0.36549*s;
    B = - 0.62903 + 0.56817*s; 
    C = - 2.4467 + 1.6783*s;
    D = 0.56575 - 0.19120*s;
    E = 1.4687 + 9.6071*s; 
    E_prime = 1.1706 + 0.99674*s; 
  }

  _beauty = pow(s,alpha)*pow(y,a)*(A + B*sqrt(y) + C*pow(y,b));
  _beauty = _beauty + pow(s,alpha_prime)*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _beauty = 9.0/(4.0*PI)*log(mu2/sqr(0.221))*_beauty*pow(1.0 - y,D);

Exit:
  return _beauty*aQED();
}

double valence_hdl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _valence = 0.0;

  double a = 0.78391 - 0.068720*s;

  double A = 1.0898 + 0.38087*s;
  double B = 0.42654 - 1.2128*s; 
  double C = - 1.6576 + 1.7075*s;
  double D = 0.96155 + 1.8441*s;

  _valence = A*pow(x,a)*(1.0 + B*sqrt(x) + C*x)*pow(1.0 - x,D);

  return _valence*aQED();
}

double sea_hdl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _sea = 0.0;

  double a = 0.72289 - 0.21562*s;
  double alpha = 0.71660;
  double beta = 1.0497;

  double A = 0.60478 + 0.036160*s;
  double B = 4.2106 - 0.85835*s; 
  double D = 4.1494 + 0.34866*s;
  double E = 4.5179 + 1.9219*s; 
  double E_prime = 5.2812 - 0.15200*s; 
  double dlg = log(1.0/x);

  _sea = 1.0 + A*sqrt(x) + B*x;
  _sea = _sea*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _sea = pow(s,alpha)*_sea*pow(1.0 - x,D)/pow(dlg,a);

  return _sea*aQED();
}

double charm_hdl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _charm = 0.0;

  double a, alpha, beta;
  double A, B, D, E, E_prime;

  double dlg = log(1.0/x);
  double y = x + 1.0 - mu2/(mu2 + 6.76);

  if (y > 1.0) goto Exit;

  if (mu2 <= 10.0)
  {
    a = 1.6248 - 0.70433*s;
    alpha = 5.6729;
    beta = 1.4575;

    A = - 2586.4 + 1910.1*s;
    B = 2695.0 - 1688.2*s; 
    D = 1.5146 + 3.1028*s;
    E = - 3.9185 + 11.738*s;
    E_prime = 3.6126 - 1.0291*s; 
  }

  if (mu2 > 10.0)
  {
    a = - 0.78809 + 0.90278*s;
    alpha = - 1.6470;
    beta = 0.72738;

    A = - 2.0561 + 0.75576*s;
    B = 2.1266 + 0.66383*s; 
    D = 3.0301 - 1.7499*s + 1.6466*sqr(s);
    E = 4.1282 + 1.6929*s - 0.26292*sqr(s); 
    E_prime = 0.89599 + 1.2761*s - 0.15061*sqr(s); 
  }

  _charm = 1.0 + A*sqrt(y) + B*y;
  _charm = _charm*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _charm = pow(s,alpha)*_charm*pow(1.0 - y,D)/pow(dlg,a);

Exit:
  return _charm*aQED();
}

double beauty_hdl(double x, double mu2)
{
  double s = log(log(mu2/sqr(0.221))/log(0.25/sqr(0.221)));
  double _beauty = 0.0;

  double a, alpha, beta;
  double A, B, D, E, E_prime;

  double dlg = log(1.0/x);
  double y = x + 1.0 - mu2/(mu2 + 73.96);

  if (y > 1.0) goto Exit;

  if (mu2 <= 100.0)
  {
    a = 0.82278 + 0.081818*s;
    alpha = - 10.210;
    beta = - 2.2296;

    A = - 99.613 + 171.25*s;
    B = 492.61 - 420.45*s; 
    D = 3.3917 + 0.084256*s;
    E = 5.6829 - 0.23571*s;
    E_prime = - 2.0137 + 4.6955*s; 
  }

  if (mu2 > 100.0)
  {
    a = - 0.98933 + 0.42366*s + 0.15817*sqr(s);
    alpha = 2.4198;
    beta = 0.40703;

    A = - 2.1109 + 1.2711*s;
    B = 9.0196 - 3.6082*s; 
    D = 3.6455 - 4.1353*s + 2.3615*sqr(s);
    E = 4.6196 + 2.4212*s; 
    E_prime = 0.66454 + 1.1109*s; 
  }

  _beauty = 1.0 + A*sqrt(y) + B*y;
  _beauty = _beauty*exp( - E + sqrt(E_prime*pow(s,beta)*dlg));
  _beauty = pow(s,alpha)*_beauty*pow(1.0 - y,D)/pow(dlg,a);

Exit:
  return _beauty*aQED();
}

