// Unit name: grv92.cpp
// Author: Artem Lipatov
// Last modified: 25.09.2009
// Description:
//   GRV-92 (collinear) parton densities in a photon

#include <iostream>
#include <math.h>
#include "grv92.h"
#include "utils.h"

using namespace std;

double grv92gLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.535 - 0.504*sqrt(s) + 0.288*sqr(s);
  double b = 0.364 - 0.520*s; 
  double c = - 0.323 + 0.115*sqr(s);
  double d = 0.233 + 0.790*s - 0.139*sqr(s); 
  double e = 0.893 + 1.968*s; 
  double f = 3.432 + 0.392*s; 
  double l = log(1.0/x);

  return aQED()*((pow(x,0.462 - 0.524*sqrt(s))*(a + b*sqrt(x) + c*pow(x,5.451 - 
    0.804*sqr(s))) + pow(s,0.676)*exp( - e + sqrt(f*pow(s,1.089)*l)))*pow(1.0 - x,d));
}

double grv92uLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.235 + 0.046*sqrt(s);
  double b = 0.082 - 0.051*s + 0.168*sqr(s); 
  double c = 0.459*s;
  double d = 0.354 - 0.061*s; 
  double e = 4.899 + 1.678*s; 
  double f = 2.046 + 1.389*s; 
  double l = log(1.0/x);

  return aQED()*((pow(x,0.500 - 0.176*s)*(a + b*sqrt(x) + c*pow(x,15.0 - 5.687*sqrt(s) - 
    0.552*sqr(s))) + pow(s,1.717)*exp( - e + sqrt(f*pow(s,0.641)*l)))*pow(1.0 - x,d));
}

double grv92dLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.233 + 0.302*s;
  double b = - 0.818*s + 0.198*sqr(s); 
  double c = 0.114 + 0.154*s;
  double d = 0.405 - 0.195*s + 0.046*sqr(s); 
  double e = 4.807 + 1.226*s; 
  double f = 2.166 + 0.664*s;
  double l = log(1.0/x);

  return aQED()*((pow(x,0.496 + 0.026*s)*(a + b*sqrt(x) + c*pow(x,0.685 - 0.580*sqrt(s) + 
    0.680*sqr(s))) + pow(s,1.549)*exp( - e + sqrt(f*pow(s,0.782)*l)))*pow(1.0 - x,d));
}

double grv92sLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.121 - 0.068*sqrt(s);
  double b = - 0.090 + 0.074*s; 
  double c = 0.062 + 0.034*s;
  double d = 0.226*s - 0.060*sqr(s); 
  double e = 4.288 + 1.707*s; 
  double f = 2.122 + 0.656*s;
  double l = log(1.0/x);

  return aQED()*(s*(pow(x,0.470 - 0.099*sqr(s))*(a + b*sqrt(x) + c*pow(x,3.246)) + 
    pow(s,1.609)*exp( - e + sqrt(f*pow(s,0.962)*l)))*pow(1.0 - x,d));
}

double grv92cLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.658 + 0.202*s;
  double b = - 0.699; 
  double c = 0.965;
  double d = 0.141*s - 0.027*sqr(s); 
  double e = 4.911 + 0.969*s; 
  double f = 2.796 + 0.952*s;
  double l = log(1.0/x);

  if (s < 0.888) return 0.0;
    else return aQED()*((s - 0.888)*(pow(x,1.254 - 0.251*s)*(a + b*sqrt(x) + c*pow(x,3.932 - 
      0.327*sqr(s))) + pow(s - 0.888,0.970)*exp( - e + sqrt(f*pow(s,0.545)*l)))*pow(1.0 - x,d));
}

double grv92bLO(double x, double mu2)
{
  if ( (x >= 1.0) OR (x <= 0.0) ) return 0.0;

  double s = log(log(mu2/sqr(0.232))/log(0.25/sqr(0.232)));

  double a = 0.815 + 0.207*s;
  double b = - 2.275; 
  double c = 1.480;
  double d = - 0.223 + 0.173*s; 
  double e = 5.426 + 0.623*s; 
  double f = 3.819 + 0.901*s;
  double l = log(1.0/x);

  if (s < 1.351) return 0.0;
    else return aQED()*((s - 1.351)*(pow(x,1.961 - 0.370*s)*(a + b*sqrt(x) + c*pow(x,0.923 + 
      0.119*s)) + pow(s - 1.351,1.016)*exp( - e + sqrt(f*pow(s,0.338)*l)))*pow(1.0 - x,d));
}
