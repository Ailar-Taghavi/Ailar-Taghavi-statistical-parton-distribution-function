// Unit name: vector4.cpp
// Author: Artem Lipatov
// Last modified: 27.05.2010

#include <iostream>
#include <math.h>
#include <stdlib.h>
#include "utils.h"
#include "vector4.h"

using namespace std;

vector4::vector4(void)
{
  for (short int I = 0; I < 4; I++) 
    component[I] = 0.0;
}

vector4::vector4(double num0, double num1, double num2, double num3)
{
  component[0] = num0;
  component[1] = num1;
  component[2] = num2;
  component[3] = num3;
}

vector4 & vector4::operator = (const vector4 & other)
{
  if (this != &other)
  {
    for (short int I = 0; I < 4; I++)
      component[I] = other.component[I];
  }

  return *this;
}

double vector4::get(short int I)
{
  check_index(I);
  return component[I];
}

void vector4::set(short int I, double numI)
{
  check_index(I);
  component[I] = numI;
}

void vector4::set(double num0, double num1, double num2, double num3)
{
  component[0] = num0;
  component[1] = num1;
  component[2] = num2;
  component[3] = num3;
}

void vector4::check_index(short int I)
{
  if ( (I < 0) OR (I > 3) )
  {
    cout << "  Error (vector): incorrect value of vector index. Program will be terminated..." << endl; 
    exit(0);
  }
}

void vector4::display(const char* title)
{
  cout << title << "[0] = " << component[0] << " " << title << "[1] = " << component[1] << " " << title << "[2] = " << component[2] << " " << title << "[3] = " << component[3] << endl;
}

void vector4::rotateXY(double csphi, double snphi)
{
  double x = component[1];  
  double y = component[2];  

  component[1] = x*csphi - y*snphi;
  component[2] = x*snphi + y*csphi;
}

void vector4::rotateXZ(double csphi, double snphi)
{
  double x = component[1];  
  double z = component[3];  

  component[1] = x*csphi - z*snphi;
  component[3] = x*snphi + z*csphi;
}

void vector4::rotateYZ(double csphi, double snphi)
{
  double y = component[2];  
  double z = component[3];  

  component[2] = y*csphi - z*snphi;
  component[3] = y*snphi + z*csphi;
}

void vector4::boostOX(double beta, double gamma)
{
  double t = component[0];
  double x = component[1];

  component[1] = x*gamma - t*gamma*beta;
  component[0] = t*gamma - x*gamma*beta;
}

void vector4::boostOY(double beta, double gamma)
{
  double t = component[0];
  double y = component[2];

  component[2] = y*gamma - t*gamma*beta;
  component[0] = t*gamma - y*gamma*beta;
}

void vector4::boostOZ(double beta, double gamma)
{
  double t = component[0];
  double z = component[3];

  component[3] = z*gamma - t*gamma*beta;
  component[0] = t*gamma - z*gamma*beta;
}

double vector4::squared(void)
{
  return sqr(component[0]) - sqr(component[1]) - sqr(component[2]) - sqr(component[3]);
}

double vector4::momentum(void)
{
  return sqrt(momentum2());
}

double vector4::momentum2(void)
{
  return sqr(component[1]) + sqr(component[2]) + sqr(component[3]);
}

double vector4::transverse_momentum(void)
{
  return sqrt(transverse_momentum2());
}

double vector4::transverse_momentum2(void)
{
  return sqr(component[1]) + sqr(component[2]);
}

double vector4::transverse_energy(void)
{
  return component[0]*transverse_momentum()/momentum();
}

double vector4::rapidity(void)
{
  return 0.5*log((component[0] + component[3])/(component[0] - component[3]));
}

double vector4::pseudo_rapidity(void)
{
  return ( - log(tan(0.5*acos(component[3]/momentum()))) );
}

double dot(vector4 p1, vector4 p2)
{
  return ( p1.get(0)*p2.get(0) - p1.get(1)*p2.get(1) - p1.get(2)*p2.get(2) - p1.get(3)*p2.get(3) );
}

double phi(vector4 p1, vector4 p2)
{
  return acos( (p1.get(1)*p2.get(1) + p1.get(2)*p2.get(2))/(p1.transverse_momentum()*p2.transverse_momentum()) );
}

double inv_mass(vector4 p1, vector4 p2)
{
  return sqrt( dot(p1,p1) + dot(p2,p2) + 2.0*dot(p1,p2) );
}

void times(vector4 p1, vector4 p2, vector4& k)
{
  k.set(0,0.0);
  k.set(1,p1.get(2)*p2.get(3) - p1.get(3)*p2.get(2));
  k.set(2,p1.get(3)*p2.get(1) - p1.get(1)*p2.get(3));
  k.set(3,p1.get(1)*p2.get(2) - p1.get(2)*p2.get(1));
}

void lc3(vector4 p1, vector4 p2, vector4 p3, vector4& k)
{
  double e0123 = 1.0;

  k.set(0,e0123*(p1.get(1)*p2.get(2)*p3.get(3) - p1.get(1)*p2.get(3)*p3.get(2) - p1.get(2)*p2.get(1)*p3.get(3) + 
    p1.get(2)*p2.get(3)*p3.get(1) + p1.get(3)*p2.get(1)*p3.get(2) - p1.get(3)*p2.get(2)*p3.get(1)));

  k.set(1, - e0123*( - p1.get(0)*p2.get(2)*p3.get(3) + p1.get(0)*p2.get(3)*p3.get(2) + p1.get(2)*p2.get(0)*p3.get(3) - 
    p1.get(2)*p2.get(3)*p3.get(0) - p1.get(3)*p2.get(0)*p3.get(2) + p1.get(3)*p2.get(2)*p3.get(0)));

  k.set(2, - e0123*(p1.get(0)*p2.get(1)*p3.get(3) - p1.get(0)*p2.get(3)*p3.get(1) - p1.get(1)*p2.get(0)*p3.get(3) + 
    p1.get(1)*p2.get(3)*p3.get(0) + p1.get(3)*p2.get(0)*p3.get(1) - p1.get(3)*p2.get(1)*p3.get(0)));

  k.set(3, - e0123*( - p1.get(0)*p2.get(1)*p3.get(2) + p1.get(0)*p2.get(2)*p3.get(1) + p1.get(1)*p2.get(0)*p3.get(2) - 
    p1.get(1)*p2.get(2)*p3.get(0) - p1.get(2)*p2.get(0)*p3.get(1) + p1.get(2)*p2.get(1)*p3.get(0)));
}

double lc4(vector4 p1, vector4 p2, vector4 p3, vector4 p4)
{
  double e0123 = 1.0;

  double _lc4 = e0123*(p1.get(0)*p2.get(1)*p3.get(2)*p4.get(3) - p1.get(0)*p2.get(1)*
      p3.get(3)*p4.get(2) - p1.get(0)*p2.get(2)*p3.get(1)*p4.get(3) + 
      p1.get(0)*p2.get(2)*p3.get(3)*p4.get(1) + p1.get(0)*p2.get(3)*p3.get(1)*p4.get(2) -
      p1.get(0)*p2.get(3)*p3.get(2)*p4.get(1) - p1.get(1)*p2.get(0)*
      p3.get(2)*p4.get(3) + p1.get(1)*p2.get(0)*p3.get(3)*p4.get(2) + 
      p1.get(1)*p2.get(2)*p3.get(0)*p4.get(3) - p1.get(1)*p2.get(2)*p3.get(3)*p4.get(0) -
      p1.get(1)*p2.get(3)*p3.get(0)*p4.get(2) + p1.get(1)*p2.get(3)*
      p3.get(2)*p4.get(0) + p1.get(2)*p2.get(0)*p3.get(1)*p4.get(3) - 
      p1.get(2)*p2.get(0)*p3.get(3)*p4.get(1) - p1.get(2)*p2.get(1)*p3.get(0)*p4.get(3) +
      p1.get(2)*p2.get(1)*p3.get(3)*p4.get(0) + p1.get(2)*p2.get(3)*
      p3.get(0)*p4.get(1) - p1.get(2)*p2.get(3)*p3.get(1)*p4.get(0) - 
      p1.get(3)*p2.get(0)*p3.get(1)*p4.get(2) + p1.get(3)*p2.get(0)*p3.get(2)*p4.get(1) +
      p1.get(3)*p2.get(1)*p3.get(0)*p4.get(2) - p1.get(3)*p2.get(1)*
      p3.get(2)*p4.get(0) - p1.get(3)*p2.get(2)*p3.get(0)*p4.get(1) + 
      p1.get(3)*p2.get(2)*p3.get(1)*p4.get(0));

  return _lc4;
}

double azimuthalangle(vector4 p1, vector4 p2)
{
  double cosphi = (p1.get(1)*p2.get(1) + p1.get(2)*p2.get(2))/(p1.transverse_momentum()*p2.transverse_momentum());
  
  if (cosphi > 1.0) cosphi = 1.0;
  if (cosphi < - 1.0) cosphi = - 1.0;
  
  return acos(cosphi);
}
