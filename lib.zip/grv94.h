#ifndef GRV94_H
#define GRV94_H

// GRV-94/92 parton densities in a proton (multiplied by x)

extern double grv94uvLO(double x, double mu2);        // u - \bar u 
extern double grv94dvLO(double x, double mu2);        // d - \bar d 
extern double grv94delLO(double x, double mu2);       // \bar d - \bar u 
extern double grv94udbLO(double x, double mu2);       // \bar u + \bar d 
extern double grv94sLO(double x, double mu2);         // s = \bar s 
extern double grv94cLO(double x, double mu2);         // c = \bar c 
extern double grv94bLO(double x, double mu2);         // b = \bar b 
extern double grv94gLO(double x, double mu2);         // gluon 

#endif
