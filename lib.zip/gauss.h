#ifndef GAUSS_H
#define GAUSS_H

extern double gauss(double (*f)(double), double a, double b, double eps);  

#endif
