#ifndef TMDPDF_H
#define TMDPDF_H

const unsigned int NPOINTMAX = 100;

class tmdpdf {
public:
  tmdpdf(void);
  ~tmdpdf(void);

  void load(const char *filename);
  void compute(double x, double kt2, double mu2);

  double pdf(void);

private:
  double* _xarr;
  double* _kt2arr;
  double* _mu2arr;
  double* _pdfarr;

  double _pdfv;

  double _xmin, _xmax;
  double _kt2min, _kt2max;
  double _mu2min, _mu2max;

  long int _size;
  unsigned int _size1;
  unsigned int _size2;
  unsigned int _size3;

  double _x[NPOINTMAX];
  double _kt2[NPOINTMAX];
  double _mu2[NPOINTMAX];
};

#endif
