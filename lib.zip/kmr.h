#ifndef KMR_H
#define KMR_H

double tg(double kt2, double mu2);
double tq(double kt2, double mu2);
double kmr_gluon(double x, double kt2, double mu2);
double kmru(double x, double kt2, double mu2);  
double kmrd(double x, double kt2, double mu2);    
double kmrs(double x, double kt2, double mu2);    
double kmrc(double x, double kt2, double mu2);    
double kmrb(double x, double kt2, double mu2);    
double kmr_ub(double x, double kt2, double mu2);  
double kmr_db(double x, double kt2, double mu2);
double kmrddb(double x, double kt2, double mu2); 
double kmruub(double x, double kt2, double mu2);        
double kmr_u(double x, double kt2, double mu2);  
double kmr_d(double x, double kt2, double mu2);    
double kmr_s(double x, double kt2, double mu2);    
double kmr_c(double x, double kt2, double mu2);
double kmr_cb(double x, double kt2, double mu2);
double kmr_t(double x, double kt2, double mu2);
double kmr_tb(double x, double kt2, double mu2);
double kmr_sb(double x, double kt2, double mu2);        
double kmr_b(double x, double kt2, double mu2);    
double kmr_bb(double x, double kt2, double mu2);    
double kmr_uv(double x, double kt2, double mu2);  
double kmr_dv(double x, double kt2, double mu2);  
double kmrseau(double x, double kt2, double mu2);    
double kmrsead(double x, double kt2, double mu2);    
#endif


