
#include <math.h>
#include "dglap.h"
#include "kmr.h"
#include "pdf.h"
#include "gauss.h"
#include "utils.h"
const double kt02 = sqr(1.0);                  
extern pdf *KMR_INPUT;
 const double eps = 1.0e-06;                    // integrating accuracy

static double _x, _kt2, _mu2;    
static double delta(double kt2, double mu2)    
{
  double kt = sqrt(kt2);
  double mu = sqrt(mu2);
  return mu/(mu + kt);
}
   double unftq(double pt2)
  {
    double zmax = delta(pt2,_mu2);
    return - 2.0*(aQCD(pt2)/(2.0*PI*pt2))*(sqr(zmax) + 2.0*zmax + 4.0*log(1.0 - zmax))/3.0; 
  }
  double unftg(double pt2)
  {
    double zmax = delta(pt2,_mu2);
    double zmin = 1.0 - zmax;
    
    return (aQCD(pt2)/(2.0*PI*pt2))*(6.0*(((zmax*zmax*zmax)/3)
       -((zmax*zmax*zmax*zmax)/4) -(zmax*zmax)-log(1-zmax)) 
	   + (NF/6)*(3*(zmax) - 3*(zmax*zmax) 
	   + 2*(zmax*zmax*zmax)));
  }
  
  double tq(double kt2, double mu2)
  {
    if (kt2 < mu2) return exp ( - gauss(&unftq,kt2,mu2,ZERO));
      else return 1.0;
  }

  double tg(double kt2, double mu2)
  {
    if (kt2 < mu2) return exp ( - gauss(&unftg,kt2,mu2,ZERO));
      else return 1.0;
  }

  double _qgluon( double z)
  {double u = KMR_INPUT->u(_x/z,_kt2) + KMR_INPUT->ubar(_x/z,_kt2);
  double d = KMR_INPUT->d(_x/z,_kt2) + KMR_INPUT->dbar(_x/z,_kt2);
  double s = KMR_INPUT->s(_x/z,_kt2) + KMR_INPUT->sb(_x/z,_kt2);
  double c = KMR_INPUT->c(_x/z,_kt2) + KMR_INPUT->cb(_x/z,_kt2);
  double b = KMR_INPUT->b(_x/z,_kt2) + KMR_INPUT->bb(_x/z,_kt2);
  double t = KMR_INPUT->t(_x/z,_kt2) + KMR_INPUT->tb(_x/z,_kt2);

if (z >= delta(_kt2,_mu2)) return 0.0;

 else return Pgq(z)*(u + d + s + c + b + t);

}

double _gg(double z)
{ if (z >= delta(_kt2,_mu2)) return 0.0;
	else  return Pgg(z)* KMR_INPUT->gluon(_x/z,_kt2);
	       
 }

double kmr_gluon(double x, double kt2, double mu2)
{ _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
double _qgluon( double z);
double _gg(double z);

  if (kt2 <= kt02) return KMR_INPUT->gluon(x,kt02)*tg(kt02,mu2)/kt02;
else{
 double dy=(1-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+= _qgluon(y)+_gg(y);
 else
 sum2+= _qgluon(y)+_gg(y);
 y+=dy;
 }
 A= _qgluon(x)+ _qgluon(1.0)+_gg(x)+_gg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tg(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }

}
double _kmru( double z)
{

 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->u(_x/z,_kt2);
          

}

double _kmrd( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->d(_x/z,_kt2);
          
}

double _kmrdb( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->dbar(_x/z,_kt2);
          
}
double kmr_db( double x, double kt2, double mu2)
 {
double _kmrdb( double z);
double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->dbar(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrdb(y)+_kmrqg(y);
 else
 sum2+=_kmrdb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrdb(x)+_kmrqg(x)+_kmrqg(1.0)+_kmrdb(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_d( double x, double kt2, double mu2)
 {
double _kmrd( double z);
double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->d(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrd(y)+_kmrqg(y);
 else
 sum2+=_kmrd(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrd(x)+_kmrqg(x)+_kmrqg(1.0)+_kmrd(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double _kmrub( double z)
{
 if (z > delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->ubar(_x/z,_kt2);
          
}
double kmr_ub( double x, double kt2, double mu2)
 {double _kmrub( double z);
  double _kmru( double z);
double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->ubar(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50.0);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrub(y)+_kmrqg(y);
 else
 sum2+=_kmrub(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrub(x)+_kmrub(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_u( double x, double kt2, double mu2)
 {double _kmrub( double z);
  double _kmru( double z);
double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->u(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50.0);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmru(y)+_kmrqg(y);
 else
 sum2+=_kmru(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmru(x)+_kmru(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double _kmrs( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->s(_x/z,_kt2);
          
}
double _kmrsb(double z)
	{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->sb(_x/z,_kt2);
          
}
double _kmrqg(double z)
{
	 if (z >= delta(_kt2,_mu2)) return 0.0;

   else  return (1.0/2.0)*Pqg(z)*KMR_INPUT->gluon(_x/z,_kt2);
}

	
double kmr_s( double x, double kt2, double mu2)
 {double _kmrs( double z);
	double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->s(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrs(y)+_kmrqg(y);
 else
 sum2+=_kmrs(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrs(x)+_kmrqg(x)+_kmrqg(1.0)+_kmrs(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_sb( double x, double kt2, double mu2)
 {double _kmrsb( double z);
	double _kmrqg(double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->sb(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrsb(y)+_kmrqg(y);
 else
 sum2+=_kmrsb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrsb(x)+_kmrqg(x)+_kmrqg(1.0)+_kmrsb(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double _kmrb( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->b(_x/z,_kt2);
          
}
double _kmrbb( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->bb(_x/z,_kt2);
          
}
double kmr_b( double x, double kt2, double mu2)
 {double _kmrb( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->b(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrb(y)+_kmrqg(y);
 else
 sum2+=_kmrb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrb(x)+_kmrb(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_bb( double x, double kt2, double mu2)
 {double _kmrbb( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->bb(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrbb(y)+_kmrqg(y);
 else
 sum2+=_kmrbb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrbb(x)+_kmrbb(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}

double _kmrc( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->c(_x/z,_kt2);
          
}
double _kmrt( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->t(_x/z,_kt2);
          
}
double _kmrtb( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->tb(_x/z,_kt2);
          
}
double _kmrcb( double z)
{
 if (z >= delta(_kt2,_mu2)) return 0.0;
else	return Pqq(z)*KMR_INPUT->cb(_x/z,_kt2);
          
}

double kmr_c( double x, double kt2, double mu2)
 {double _kmrc( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->c(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrc(y)+_kmrqg(y);
 else
 sum2+=_kmrc(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrc(x)+_kmrc(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_tb( double x, double kt2, double mu2)
 {double _kmrtb( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->tb(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrtb(y)+_kmrqg(y);
 else
 sum2+=_kmrtb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrtb(x)+_kmrtb(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_t( double x, double kt2, double mu2)
 {double _kmrt( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->t(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrt(y)+_kmrqg(y);
 else
 sum2+=_kmrt(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrt(x)+_kmrt(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmr_cb( double x, double kt2, double mu2)
 {double _kmrc( double z);
	  _x = x;
  _kt2 = kt2;
  _mu2 = mu2;
 if (kt2 <= kt02) return (KMR_INPUT->cb(x,kt02))*tq(kt02,mu2)/kt02;
else
{
 double dy=(1.0-x)/double(50);
 double sum1=0, sum2=0.0,A=0.0;
 double y=x+dy;
 for(int i=1; i< 50.0; i++)
 {
 if(i%2!=0)
 sum1+=_kmrcb(y)+_kmrqg(y);
 else
 sum2+=_kmrcb(y)+_kmrqg(y);
 y+=dy;
 }
 A=_kmrcb(x)+_kmrcb(1.0)+_kmrqg(x)+_kmrqg(1.0)+4.0*sum1+2.0*sum2;
 A*=dy/double(3.0);
 return tq(kt2,mu2)*aQCD(kt2)*A/(2.0*PI*kt2);
 }
}
double kmrseau(double x, double kt2, double mu2)
{
  if (kt2 > kt02) return  tq(kt2,mu2)*(aQCD(kt2)/(2.0*PI*kt2))*gauss(&_kmrqg,x,1.0,eps);
    else  return (KMR_INPUT->ubar(x,kt02))*tq(kt02,mu2)/kt02;   
}
double kmrsead(double x, double kt2, double mu2)
{
  if (kt2 > kt02) return  tq(kt2,mu2)*(aQCD(kt2)/(2.0*PI*kt2))*gauss(&_kmrqg,x,1.0,eps);
    else return (KMR_INPUT->dbar(x,kt02))*tq(kt02,mu2)/kt02;
}
