#ifndef INTERFACE_H
#define INTERFACE_H

enum model {LO, kT};

extern void display(model MODEL, unsigned int PDF);
extern void display(model MODEL, unsigned int PDF1, unsigned int PDF2);

#endif

