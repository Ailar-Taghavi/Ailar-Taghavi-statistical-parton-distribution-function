// Unit name: pdf.cpp
// Author: Artem Lipatov
// Last modified: 25.09.2009

#include <stdio.h>
#include <iostream>
#include <math.h>
#include "utils.h"
#include "grv92.h"
#include "grv94.h"
#include "cjkl.h"
#include "pdf.h"

using namespace std;

pdf::pdf(unsigned int _set)
{
  set = _set;

  if (set == MSTW2008) mstwpdf = new c_mstwpdf("mstw2008lo.00.dat");
}

pdf::pdf(unsigned int _set, const char *FileName)
{
  set = _set;

  if (set == MSTW2008) mstwpdf = new c_mstwpdf(FileName);
}

pdf::~pdf()
{
  if (set == MSTW2008) delete mstwpdf;
}

double pdf::gluon(double x, double mu2)
{
  double _gluon = 0.0;

  if (set == GRV94) _gluon = grv94gLO(x,mu2);
  if (set == MSTW2008) _gluon = mstwpdf->parton(0,x,sqrt(mu2));
  if (set == GRV92) _gluon = grv92gLO(x,mu2);
  if (set == CJKL2002) _gluon = cjkl_gluon(x,mu2);

  return _gluon;
}

double pdf::u(double x, double mu2)
{
  double _u = 0.0;

  if (set == GRV94) _u = grv94uvLO(x,mu2) + ubar(x,mu2);
  if (set == MSTW2008) _u = mstwpdf->parton(2,x,sqrt(mu2));
  if (set == GRV92) _u = grv92uLO(x,mu2);
  if (set == CJKL2002) _u = cjkl_up(x,mu2);

  return _u;
}

double pdf::ubar(double x, double mu2)
{
  double _ubar = 0.0;

  if (set == GRV94) _ubar = 0.5*(grv94udbLO(x,mu2) - grv94delLO(x,mu2));
  if (set == MSTW2008) _ubar = mstwpdf->parton(-2,x,sqrt(mu2));
  if (set == GRV92) _ubar = grv92uLO(x,mu2);
  if (set == CJKL2002) _ubar = cjkl_up(x,mu2);

  return _ubar;
}

double pdf::uv(double x, double mu2)
{
  double _uv = 0.0;

  if (set == GRV94) _uv = grv94uvLO(x,mu2);
  if (set == MSTW2008) _uv = mstwpdf->parton(8,x,sqrt(mu2));

  return _uv;
}

double pdf::d(double x, double mu2)
{
  double _d = 0.0;

  if (set == GRV94) _d = grv94dvLO(x,mu2) + dbar(x,mu2);
  if (set == MSTW2008) _d = mstwpdf->parton(1,x,sqrt(mu2));
  if (set == GRV92) _d = grv92dLO(x,mu2);
  if (set == CJKL2002) _d = cjkl_down(x,mu2);

  return _d;
}

double pdf::dbar(double x, double mu2)
{
  double _dbar = 0.0;

  if (set == GRV94) _dbar = 0.5*(grv94udbLO(x,mu2) + grv94delLO(x,mu2));
  if (set == MSTW2008) _dbar = mstwpdf->parton(-1,x,sqrt(mu2));
  if (set == GRV92) _dbar = grv92dLO(x,mu2);
  if (set == CJKL2002) _dbar = cjkl_down(x,mu2);

  return _dbar;
}

double pdf::dv(double x, double mu2)
{
  double _dv = 0.0;

  if (set == GRV94) _dv = grv94dvLO(x,mu2);
  if (set == MSTW2008) _dv = mstwpdf->parton(7,x,sqrt(mu2));

  return _dv;
}

double pdf::s(double x, double mu2)
{
  double _s = 0.0;

  if (set == GRV94) _s = grv94sLO(x,mu2);
  if (set == MSTW2008) _s = mstwpdf->parton(3,x,sqrt(mu2));
  if (set == GRV92) _s = grv92sLO(x,mu2);
  if (set == CJKL2002) _s = cjkl_strange(x,mu2);

  return _s;
}
double pdf::sb(double x, double mu2)
{
  double _sb = 0.0;
  if (set == MSTW2008) _sb = mstwpdf->parton(-3,x,sqrt(mu2));
  return _sb;
}
double pdf::c(double x, double mu2)
{
  double _c = 0.0;

  if (set == GRV94) _c = grv92cLO(x,mu2);
  if (set == MSTW2008) _c = mstwpdf->parton(4,x,sqrt(mu2));
  if (set == GRV92) _c = grv92cLO(x,mu2);
  if (set == CJKL2002) _c = cjkl_charm(x,mu2);

  return _c;
}

double pdf::cb(double x, double mu2)
{
  double _cb = 0.0;
  if (set == MSTW2008) _cb = mstwpdf->parton(-4,x,sqrt(mu2));
  return _cb;
}
double pdf::b(double x, double mu2)
{
  double _b = 0.0;

  if (set == GRV94) _b = grv92bLO(x,mu2);
  if (set == MSTW2008) _b = mstwpdf->parton(5,x,sqrt(mu2));
  if (set == GRV92) _b = grv92bLO(x,mu2);
  if (set == CJKL2002) _b = cjkl_beauty(x,mu2);

  return _b;
}
double pdf::bb(double x, double mu2)
{
  double _bb = 0.0;
  if (set == MSTW2008) _bb = mstwpdf->parton(-5,x,sqrt(mu2));
  return _bb;
}
double pdf::t(double x, double mu2)
{
  double _t = 0.0;

  if (set == MSTW2008) _t = mstwpdf->parton(6,x,sqrt(mu2));


  return _t;
}
double pdf::tb(double x, double mu2)
{
  double _tb = 0.0;

  if (set == MSTW2008) _tb = mstwpdf->parton(-6,x,sqrt(mu2));


  return _tb;
}

