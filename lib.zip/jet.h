#include "utils.h"
#include "vector4.h"

#ifndef JET_H
#define JET_H

extern void choose(vector4 p1, vector4 p2, vector4& pjet);     
extern void choose(vector4 p1, vector4 p2, vector4 p3, vector4& pjet);     
extern void choose(vector4 p1, vector4 p2, vector4 p3, vector4 p4, vector4& pjet);     

extern void choose2(vector4 p1, vector4 p2, vector4& pjet1, vector4& pjet2);     

extern void parton2jet(vector4 p1, vector4& p2, double ymin, double ymax);
extern void parton2jet(vector4 p1, vector4& p2, double ymin, double ymax, double factor);

extern boolean isolated_cone(vector4 p1, vector4 p2);
extern boolean separated_cone(vector4 p1, vector4 p2);

#endif

