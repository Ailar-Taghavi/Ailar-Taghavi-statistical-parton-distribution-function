#ifndef HISTOGRAM_H
#define HISTOGRAM_H

static const unsigned int NBINMAX = 200;

struct hbin {
  double lowerborder;
  double upperborder;
  double width;
  double value;
};

class histogram {
public:
  histogram(double hlowerborder, double hupperborder, unsigned int hnbin, const char* hname);
  histogram(double hlowerborder, double hupperborder, unsigned int hnbin, const char* hname, const char* hsuffix);
  ~histogram(void);

  void put(double x, double f);
  void saveascurve(void);
  void saveashistogram(void);
  void saveascurve(const char *filename);
  void saveashistogram(const char *filename);
  void load(const char *filename);
  void format(unsigned int id, double xmin, double xmax);

  double sum(void);

private:
  double lowerborder;
  double upperborder;

  const char* name;
  unsigned int nbin;

  hbin* bin;
};

#endif
