// Unit name: tmdpdf.cpp
// Author: Artem Lipatov
// Last modified: 27.09.2014

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "tmdpdf.h"
#include "utils.h"

using namespace std;

tmdpdf::tmdpdf(void)
{
  _pdfv = 0.0;

  _size = 0;

  _size1 = 0;
  _size2 = 0;
  _size3 = 0;
}

tmdpdf::~tmdpdf()
{
  delete _xarr;
  delete _kt2arr;
  delete _mu2arr;
  delete _pdfarr;
}

void tmdpdf::load(const char *filename)
{
  FILE *file;

  float x, kt2, mu2, pdf;

  _xmin = 1.0;
  _xmax = 0.0;

  _kt2min = 1.0e+10;
  _kt2max = 0.0;

  _mu2min = 1.0e+10;
  _mu2max = 0.0;

  if ((file = fopen(filename,"r")) == NULL)
  {
    cout << "File '" << filename << "' is absent. Program terminated." << endl;
    exit(0);
  }

  _size = 0;
  while (fscanf(file,"%f %f %f %f",&x,&kt2,&mu2,&pdf) != EOF)
    _size = _size + 1;

  _xarr = new double[_size];
  _kt2arr = new double[_size];
  _mu2arr = new double[_size];
  _pdfarr = new double[_size];

  rewind(file);

  long int i = 0;
  while (fscanf(file,"%f %f %f %f",&x,&kt2,&mu2,&pdf) != EOF)
  {
    _xarr[i] = exp(x);
    _kt2arr[i] = exp(kt2);
    _mu2arr[i] = exp(mu2);

    _pdfarr[i] = pdf/_kt2arr[i];

    if (_xarr[i] < _xmin) _xmin = _xarr[i];
    if (_xarr[i] > _xmax) _xmax = _xarr[i];

    if (_kt2arr[i] < _kt2min) _kt2min = _kt2arr[i];
    if (_kt2arr[i] > _kt2max) _kt2max = _kt2arr[i];

    if (_mu2arr[i] < _mu2min) _mu2min = _mu2arr[i];
    if (_mu2arr[i] > _mu2max) _mu2max = _mu2arr[i];

    i++;
  }

  fclose(file);

  unsigned int n1 = 0;
  unsigned int n2 = 0;
  unsigned int n3 = 0;

  for (long int i = 0; i < _size; i++)
  {
    _x[n1] = _xarr[i];
    if (n1 == 0) n1++;
    else
      if (_x[n1] > _x[n1 - 1]) n1++;

    _kt2[n2] = _kt2arr[i];
    if (n2 == 0) n2++;
    else
      if (_kt2[n2] > _kt2[n2 - 1]) n2++;

   _mu2[n3] = _mu2arr[i];
    if (n3 == 0) n3++;
    else
      if (_mu2[n3] > _mu2[n3 - 1]) n3++;
  }

  _size1 = n1;
  _size2 = n2;
  _size3 = n3;

  cout << "Reading PDF grid from " << filename << endl;
}

void tmdpdf::compute(double x, double kt2, double mu2)
{
  double x1 = _xmin;
  double x2 = _xmax;

  double y1 = _kt2min;
  double y2 = _kt2max;

  double z1 = _mu2min;
  double z2 = _mu2max;

  double f111, f112, f121, f122, f211, f212, f221, f222;

  if (x < _xmin) { x = _xmin + ZERO; }
  if (x > _xmax) { x = _xmax - ZERO; }

  if (kt2 < _kt2min) { kt2 = _kt2min + ZERO; }
  if (kt2 > _kt2max) { kt2 = _kt2max - ZERO; }

  if (mu2 < _mu2min) { mu2 = _mu2min + ZERO; }
  if (mu2 > _mu2max) { mu2 = _mu2max - ZERO; }

  unsigned int i1 = 0;
  for (int i = 0; i < _size1 - 1; i++)
    if ( (x > _x[i]) and (x < _x[i + 1]) )
    {
      x1 = _x[i];
      x2 = _x[i + 1];
      i1 = i;
      break;
    }

  unsigned int i2 = 0;
  for (int i = 0; i < _size2 - 1; i++)
    if ( (kt2 > _kt2[i]) and (kt2 < _kt2[i + 1]) )
    {
      y1 = _kt2[i];
      y2 = _kt2[i + 1];
      i2 = i;
      break;
    }

  unsigned int i3 = 0;
  for (int i = 0; i < _size3 - 1; i++)
    if ( (mu2 > _mu2[i]) and (mu2 < _mu2[i + 1]) )
    {
      z1 = _mu2[i];
      z2 = _mu2[i + 1];
      i3 = i;
      break;
    }

  f111 = _pdfarr[i3 + i1*_size3 + i2*_size1*_size3];
  f112 = _pdfarr[(i3 + 1) + i1*_size3 + i2*_size1*_size3];
  f121 = _pdfarr[i3 + i1*_size3 + (i2 + 1)*_size1*_size3];
  f122 = _pdfarr[(i3 + 1) + i1*_size3 + (i2 + 1)*_size1*_size3];
  f211 = _pdfarr[i3 + (i1 + 1)*_size3 + i2*_size1*_size3];
  f212 = _pdfarr[(i3 + 1) + (i1 + 1)*_size3 + i2*_size1*_size3];
  f221 = _pdfarr[i3 + (i1 + 1)*_size3 + (i2 + 1)*_size1*_size3];
  f222 = _pdfarr[(i3 + 1) + (i1 + 1)*_size3 + (i2 + 1)*_size1*_size3];

  _pdfv = ( f111*(x2 - x)*(y2 - kt2)*(z2 - mu2) + f112*(x2 - x)*(y2 - kt2)*(mu2 - z1) +
    f121*(x2 - x)*(kt2 - y1)*(z2 - mu2) + f122*(x2 - x)*(kt2 - y1)*(mu2 - z1) +
    f211*(x - x1)*(y2 - kt2)*(z2 - mu2) + f212*(x - x1)*(y2 - kt2)*(mu2 - z1) +
    f221*(x - x1)*(kt2 - y1)*(z2 - mu2) + f222*(x - x1)*(kt2 - y1)*(mu2 - z1) )/( (x2 - x1)*(y2 -
      y1)*(z2 - z1) );
}

double tmdpdf::pdf(void)
{
  return max(_pdfv,0.0);
}
