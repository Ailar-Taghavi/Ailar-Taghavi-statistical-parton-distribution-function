#ifndef cjkl_H
#define cjkl_H

// CJKL (collinear) LO parton densities in a photon (multiplied by x)

extern double cjkl_up(double x, double mu2);        // u = \bar u 
extern double cjkl_down(double x, double mu2);      // d = \bar d 
extern double cjkl_strange(double x, double mu2);   // s = \bar s 
extern double cjkl_charm(double x, double mu2);     // c = \bar c 
extern double cjkl_beauty(double x, double mu2);    // b = \bar b 
extern double cjkl_gluon(double x, double mu2);     // gluon 

#endif
