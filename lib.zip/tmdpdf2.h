#ifndef TMDPDF2_H
#define TMDPDF2_H

#include "tmdpdf.h"

class tmdpdf2 {
public:
  tmdpdf2(void);
  ~tmdpdf2(void);

  void load(const char *filename);
  void compute(double x, double kt2, double mu2);

  double pdf1(void);
  double pdf2(void);

private:
  double* _xarr;
  double* _kt2arr;
  double* _mu2arr;
  double* _pdf1arr;
  double* _pdf2arr;

  double _pdf1v;
  double _pdf2v;

  double _xmin, _xmax;
  double _kt2min, _kt2max;
  double _mu2min, _mu2max;

  long int _size;
  unsigned int _size1;
  unsigned int _size2;
  unsigned int _size3;

  double _x[NPOINTMAX];
  double _kt2[NPOINTMAX];
  double _mu2[NPOINTMAX];
};

#endif
