// Unit name: histogram.cpp
// Author: Artem Lipatov
// Last modified: 26.09.2014

#include <iostream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "histogram.h"

using namespace std;

histogram::histogram(double hlowerborder, double hupperborder, unsigned int hnbin, const char* hname)
{
  nbin = hnbin;
  name = hname;

  lowerborder = hlowerborder;
  upperborder = hupperborder;
  
  bin = new hbin[nbin];

  double width = (upperborder - lowerborder)/nbin;

  for (int i = 0; i < nbin; i++)
  {
    bin[i].lowerborder = lowerborder + i*width; 
    bin[i].upperborder = bin[i].lowerborder + width; 
    bin[i].width = width;
    bin[i].value = 0.0;
  }
}

histogram::histogram(double hlowerborder, double hupperborder, unsigned int hnbin, const char* hname, const char* hsuffix)
{
  char* fullname = new char[strlen(hname) + strlen(hsuffix) + 1];

  strcpy(fullname,"");

  strcat(fullname,hname);
  strcat(fullname,hsuffix);

  nbin = hnbin;
  name = fullname;

  lowerborder = hlowerborder;
  upperborder = hupperborder;

  bin = new hbin[nbin];

  double width = (upperborder - lowerborder)/nbin;

  for (int i = 0; i < nbin; i++)
  {
    bin[i].lowerborder = lowerborder + i*width; 
    bin[i].upperborder = bin[i].lowerborder + width; 
    bin[i].width = width;
    bin[i].value = 0.0;
  }
}

histogram::~histogram(void)
{
  delete bin;
}

void histogram::put(double x, double f)
{
  if ( (x >= lowerborder) and (x <= upperborder) ) 
  {  
    for (int i = 0; i < nbin; i++)
    {  
      if ( (x >= bin[i].lowerborder) and (x <= bin[i].upperborder) )
      {
        bin[i].value += f/bin[i].width;
        goto Exit;
      }
    }  
  } 
  
Exit:
  return;   
}

void histogram::saveascurve(const char *filename)
{
  FILE *outfile;

  outfile = fopen(filename,"w");

  for (int i = 0; i < nbin; i++)
    fprintf(outfile,"%e %e\n",0.5*(bin[i].lowerborder + bin[i].upperborder),bin[i].value);

  fclose(outfile);
}

void histogram::saveashistogram(const char *filename)
{
  FILE *outfile;

  outfile = fopen(filename,"w");

  for (int i = 0; i < nbin; i++)
  {
    fprintf(outfile,"%e %e\n",bin[i].lowerborder,bin[i].value);
    fprintf(outfile,"%e %e\n",bin[i].upperborder,bin[i].value);
  }

  fclose(outfile);
}

void histogram::saveascurve(void)
{
  saveascurve(name);
}

void histogram::saveashistogram(void)
{
  saveashistogram(name);
}

void histogram::load(const char *filename)
{
  FILE *outfile;

  double xarr[2*nbin];
  double varr[2*nbin];

  float x, value;

  if ((outfile = fopen(filename,"r")) == NULL)
  {
    cout << "File '" << filename << "' is absent. Program terminated.\n";
    exit(0);
  }

  int i = 0;
  while (fscanf(outfile,"%f %f",&x,&value) != EOF)
  {
    xarr[i] = x;
    varr[i] = value;

    i++;
  }

  for (int i = 0; i < nbin; i++)
  {
    bin[i].lowerborder = xarr[2*i];
    bin[i].upperborder = xarr[2*i + 1];
    bin[i].width = bin[i].upperborder - bin[i].lowerborder;
    
    bin[i].value = varr[2*i];
  }
  
  fclose(outfile);
}

void histogram::format(unsigned int id, double lowerborder, double upperborder)
{
  if ( (id >= 0) and (id < nbin) )
  {  
    bin[id].lowerborder = lowerborder;
    bin[id].upperborder = upperborder;
    bin[id].width = upperborder - lowerborder;
  }
}

double histogram::sum(void)
{
  double s = 0.0;

  for (int i = 0; i < nbin; i++)
    s = s + bin[i].value*bin[i].width;

  return s;
}
