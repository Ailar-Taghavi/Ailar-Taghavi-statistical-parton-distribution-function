#ifndef UPDF_H
#define UPDF_H

double gbw(double x, double kt2);
double gbwmod(double x, double kt2);
double kms(double x, double kt2);

#endif


