#ifndef GRV92_H
#define GRV92_H

// GRV-92 parton densities in a photon (multiplied by x)

extern double grv92gLO(double x, double mu2);        // gluon 
extern double grv92uLO(double x, double mu2);        // u = \bar u 
extern double grv92dLO(double x, double mu2);        // d = \bar d 
extern double grv92sLO(double x, double mu2);        // s = \bar s 
extern double grv92cLO(double x, double mu2);        // c = \bar c 
extern double grv92bLO(double x, double mu2);        // b = \bar b 

#endif
