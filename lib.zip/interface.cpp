// Unit name: interface.cpp
// Author: Artem Lipatov
// Last modified: 28.09.2008

#include <iostream>
#include <stdlib.h>
#include "pdf.h"
#include "interface.h"

using namespace std;

void display(model MODEL, unsigned int PDF)
{
  switch (MODEL)
  {
    case LO: cout << "MODEL: collinear LO approximation of QCD"; break;
    case kT: cout << "MODEL: kt-factorization approach of QCD"; break;

    default: { 
               cout << " Error: there is no correct MODEL option. Program will be finished." << endl; 
               exit(0);
             }
  }  

  switch (PDF)
  {
    case GRV92: cout << " (GRV'92)" << endl; break;
    case GRV94: cout << " (GRV'94)" << endl; break;
    case MSTW2008: cout << " (MSTW'2008)" << endl; break;
    case CJKL2002: cout << " (CJKL'2002)" << endl; break;
    case KMR: cout << " (KMR)" << endl; break;
    case KMRred: cout << " (reduced KMR sea quarks)" << endl; break;
    case KMS: cout << " (KMS)" << endl; break;
    case GBW: cout << " (GBW)" << endl; break;
    case CCFM: cout << " (CCFM)" << endl; break;

    default: { 
               cout << " Error: there is no correct PDF option(s). Program will be finished." << endl; 
               exit(0);
             }

  } 
}

void display(model MODEL, unsigned int PDF1, unsigned int PDF2)
{
  switch (MODEL)
  {
    case LO: cout << "MODEL: collinear LO approximation of QCD"; break;
    case kT: cout << "MODEL: kt-factorization approach of QCD"; break;

    default: { 
               cout << " Error: there is no correct MODEL option. Program will be finished." << endl; 
               exit(0);
             }
  }  

  switch (PDF1)
  {
    case GRV92: cout << " (GRV'92 "; break;
    case CJKL2002: cout << " (CJKL'2002 "; break;
    case KMR: cout << " (KMR "; break;

    default: { 
               cout << " Error: there is no correct MODEL option. Program will be finished." << endl; 
               exit(0);
             }
  }

  switch (PDF2)
  {
    case GRV94: cout << "& GRV'94)" << endl; break;
    case MSTW2008: cout << "& MSTW'2008)" << endl; break;
    case KMR: cout << "& KMR)" << endl; break;
    case KMS: cout << "& KMS)" << endl; break;
    case GBW: cout << "& GBW)" << endl; break;
    case CCFM: cout << "& CCFM)" << endl; break;

    default: { 
               cout << " Error: there is no correct MODEL option. Program will be finished." << endl; 
               exit(0);
             }
  }
}

