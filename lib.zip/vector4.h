#ifndef VECTOR4_H
#define VECTOR4_H

class vector4 {
public:
  vector4(void);                                       
  vector4(double num0, double num1, double num2, double num3);                                       

  double get(short int I);
  void set(short int I, double numI);
  void set(double num0, double num1, double num2, double num3);

  double squared(void);
  double momentum(void);
  double momentum2(void);
  double transverse_energy(void);
  double transverse_momentum(void);
  double transverse_momentum2(void);

  double rapidity(void);
  double pseudo_rapidity(void);

  void rotateXY(double csphi, double snphi);
  void rotateXZ(double csphi, double snphi);
  void rotateYZ(double csphi, double snphi);

  void boostOX(double beta, double gamma);
  void boostOY(double beta, double gamma);
  void boostOZ(double beta, double gamma);

  void display(const char* title);  

  vector4 & operator = (const vector4 & other);

private:
  double component[4];

  void check_index(short int I);
};

double dot(vector4 p1, vector4 p2);
double phi(vector4 p1, vector4 p2);
double inv_mass(vector4 p1, vector4 p2);
double azimuthalangle (vector4 p1, vector4 p2);

void times(vector4 p1, vector4 p2, vector4& k);
void lc3(vector4 p1, vector4 p2, vector4 p3, vector4& k);
double lc4(vector4 p1, vector4 p2, vector4 p3, vector4 p4); 

#endif

